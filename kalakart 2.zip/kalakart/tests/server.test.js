"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const server = require("../server.js");

let base;
test.before(async () => { await new Promise(r => server.listen(0, r)); base = "http://127.0.0.1:" + server.address().port; });
test.after(() => server.close());

const post = body => fetch(base + "/api/inquiries", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

test("GET /api/products returns 18 products with share", async () => {
  const j = await (await fetch(base + "/api/products")).json();
  assert.equal(j.length, 18); assert.ok(j.every(p => p.sharePercent >= 75));
});

test("GET price endpoint scales with size and quantity", async () => {
  const a = await (await fetch(base + "/api/products/dhokra-tribal-figurine/price?size=m&qty=1")).json();
  const b = await (await fetch(base + "/api/products/dhokra-tribal-figurine/price?size=l&qty=2")).json();
  assert.equal(Math.round(a.total), 2400); assert.ok(b.total > a.total);
  assert.equal((await fetch(base + "/api/products/nope/price")).status, 404);
});

test("POST /api/inquiries rejects invalid data with 400", async () => {
  const r = await post({ product: "x" }); assert.equal(r.status, 400); assert.ok((await r.json()).errors.length > 0);
});

test("GET /api/inquiries is not public", async () => {
  assert.equal((await fetch(base + "/api/inquiries")).status, 401);
});

test("static files: index served, path traversal and private files blocked", async () => {
  assert.equal((await fetch(base + "/")).status, 200);
  assert.equal((await fetch(base + "/server.js")).status, 404);
  assert.equal((await fetch(base + "/package.json")).status, 404);
  assert.equal((await fetch(base + "/js/..%2f..%2fserver.js")).status, 404);
  const h = (await fetch(base + "/")).headers; assert.equal(h.get("x-content-type-options"), "nosniff");
});
