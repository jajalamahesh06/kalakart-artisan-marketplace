"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const KK = require("../js/data.js");

test("dataset: 6 artisans, 18 products, every product has a known artisan and technique", () => {
  assert.equal(KK.artisans.length, 6);
  assert.equal(KK.products.length, 18);
  for (const p of KK.products) {
    assert.ok(KK.artisanById(p.artisan), p.id + " artisan");
    assert.ok(KK.techniques[p.craft], p.id + " technique");
    assert.ok(KK.finishes[p.craft], p.id + " finishes");
  }
  assert.equal(new Set(KK.products.map(p => p.id)).size, 18, "unique ids");
});

test("brief demo: Dhokra figurine totals Rs 2,400 and splits as in the brief", () => {
  const p = KK.byId("dhokra-tribal-figurine"), c = KK.calc(p);
  assert.equal(p.raw, 400); assert.equal(c.labor, 1200); assert.equal(p.profit, 600); assert.equal(p.fee, 200);
  assert.equal(c.total, 2400);
  assert.equal(c.direct, 1800);
});

test("cost parts always add up to the total", () => {
  for (const p of KK.products) {
    const c = KK.calc(p);
    assert.equal(c.parts.reduce((s, x) => s + x.value, 0), c.total, p.id);
  }
});

test("platform pledge: artisan share is at least 75% on every product", () => {
  for (const p of KK.products) assert.ok(KK.calc(p).share >= KK.MIN_SHARE - 1e-9, p.id + " " + KK.calc(p).share);
});

test("fair-wage index = hourly rate / benchmark and is >= 1 for every product", () => {
  for (const p of KK.products) {
    const c = KK.calc(p);
    assert.equal(c.wageIndex, p.rate / KK.BENCHMARK_RATE);
    assert.ok(c.wageIndex >= 1, p.id);
  }
});

test("estimate at standard size and qty 1 equals the listed price", () => {
  for (const p of KK.products) {
    const e = KK.estimate(p, { f: 1, qty: 1 });
    assert.ok(Math.abs(e.total - KK.calc(p).total) < 0.01, p.id);
  }
});

test("estimate scales with size and quantity; artisan share stays at or above 75%", () => {
  const p = KK.byId("bidri-silver-vase");
  const small = KK.estimate(p, { f: 0.75, qty: 1 }), big = KK.estimate(p, { f: 1.5, qty: 1 }), bulk = KK.estimate(p, { f: 1, qty: 25 });
  assert.ok(small.total < KK.calc(p).total && KK.calc(p).total < big.total);
  assert.ok(bulk.total > KK.calc(p).total * 20, "25 pieces cost far more than one");
  assert.ok(bulk.total < KK.calc(p).total * 25, "bulk shipping is cheaper per piece");
  for (const e of [small, big, bulk]) assert.ok(e.share >= 75, "share " + e.share);
});

test("lead time grows with quantity and includes shipping days", () => {
  const p = KK.byId("sambalpuri-ikat-saree");
  assert.ok(KK.estimate(p, { f: 1, qty: 10 }).lead > KK.estimate(p, { f: 1, qty: 1 }).lead);
  assert.ok(KK.estimate(p, { f: 1, qty: 1 }).lead > 4);
});

const good = () => ({ product: "dhokra-tribal-figurine", type: "custom", size: "m", finish: "Natural brass", qty: 2, dims: { h: "", w: "", d: "" }, deadline: "", name: "Asha Rao", email: "asha@example.com", phone: "", city: "Pune", lang: "Hindi", msg: "Hello" });

test("validateInquiry accepts a good inquiry", () => {
  const v = KK.validateInquiry(good());
  assert.equal(v.ok, true, v.errors.join());
  assert.equal(v.clean.qty, 2);
});

test("validateInquiry rejects bad input", () => {
  const cases = [
    [{ product: "nope" }, "product"], [{ qty: 0 }, "qty"], [{ qty: 501 }, "qty"], [{ qty: 1.5 }, "qty"], [{ email: "not-an-email" }, "email"],
    [{ name: "   " }, "name"], [{ finish: "Neon pink" }, "finish"], [{ size: "xl" }, "size"], [{ deadline: "2000-01-01" }, "past deadline"],
    [{ deadline: "31/12/2030" }, "bad date"], [{ size: "c" }, "custom size needs a dimension"], [{ phone: "abc" }, "phone"]
  ];
  for (const [patch, what] of cases) assert.equal(KK.validateInquiry(Object.assign(good(), patch)).ok, false, what);
});

test("validateInquiry strips angle brackets / control characters and limits length", () => {
  const v = KK.validateInquiry(Object.assign(good(), { name: "<script>alert(1)</script>\u0007Bob", msg: "x".repeat(2000) }));
  assert.ok(!/[<>\u0007]/.test(v.clean.name));
  assert.equal(v.clean.msg.length, 500);
});
