# KalaKart — heritage handicraft marketplace

Heritage handicraft marketplace with transparent fair-price breakdowns, artisan stories, craft-technique walkthroughs and direct artisan inquiries. Plain HTML, CSS and JavaScript — zero dependencies.

## Run it
- **Static:** open `index.html` in a browser. Inquiries are saved in the browser (localStorage).
- **With backend (optional):** `npm start` → http://localhost:3000. Inquiries are validated again on the server and stored in `data/inquiries.json`.
  - `GET /api/artisans`, `GET /api/products`, `GET /api/products/:id/price?size=l&qty=3`
  - `POST /api/inquiries` (rate-limited, 20 KB body limit); `GET /api/inquiries` needs `ADMIN_TOKEN`
- **Tests:** `npm test` (Node's built-in test runner, no install needed; also run by GitHub Actions)

## Features
Gallery with region / material / price filters, search, sort and "show more" paging · artisan story + craft-origin card with village map · interactive fair-price breakdown · Artisan Direct Earnings Meter (minimum 75%) · technique walkthrough · structured inquiry form with live estimate · GI verification mock (SHA-256) · audio craft stories (Hindi, Odia, Bengali) · 360° studio tour.

## Structure
- `js/data.js` data + shared logic (price calc, estimate, input validation) used by the UI, server and tests
- `js/art.js` procedural SVG art, map, panoramas
- `js/app.js` routing and views
- `server.js` optional API · `tests/` unit + API tests · `css/style.css`

## Notes
Artisan names, stories and GI IDs are sample data. The brief's Dhokra example (₹1,200 labour + ₹600 profit of ₹2,400) gives a 75% artisan share. Real photos/audio: add `src` paths in `js/data.js` (`audio[].src`).
