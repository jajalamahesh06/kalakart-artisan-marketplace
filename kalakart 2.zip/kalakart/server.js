/* Optional zero-dependency backend for KalaKart.  Run:  npm start  (http://localhost:3000)
   - Serves the static site
   - REST API: GET /api/artisans, /api/products, /api/products/:id/price?size=l&qty=3
               POST /api/inquiries  (validated + sanitised server-side, stored in data/inquiries.json)
               GET  /api/inquiries  (needs  Authorization: Bearer $ADMIN_TOKEN)           */
"use strict";
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const KK = require("./js/data.js");

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DB = path.join(ROOT, "data", "inquiries.json");
const MAX_BODY = 20 * 1024;
const MIME = { ".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".json": "application/json", ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg", ".mp3": "audio/mpeg", ".mp4": "video/mp4", ".ico": "image/x-icon" };
const PUBLIC = new Set(["index.html", "css", "js", "media"]);

const HEADERS = {
  "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
  "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; media-src 'self'; connect-src 'self'; frame-ancestors 'none'"
};

function readDb() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch (e) { return []; } }
function writeDb(list) {
  fs.mkdirSync(path.dirname(DB), { recursive: true });
  const tmp = DB + ".tmp"; fs.writeFileSync(tmp, JSON.stringify(list, null, 2)); fs.renameSync(tmp, DB);   // atomic write
}
function send(res, code, body, type) {
  res.writeHead(code, Object.assign({ "Content-Type": type || "application/json; charset=utf-8", "Cache-Control": "no-store" }, HEADERS));
  res.end(typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", c => { size += c.length; if (size > MAX_BODY) { reject(Object.assign(new Error("too large"), { code: 413 })); req.destroy(); } else chunks.push(c); });
    req.on("end", () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString() || "{}")); } catch (e) { reject(Object.assign(new Error("bad json"), { code: 400 })); } });
    req.on("error", reject);
  });
}

/* tiny in-memory rate limit: 10 inquiries / minute / IP */
const hits = new Map();
function limited(ip) {
  const now = Date.now(), arr = (hits.get(ip) || []).filter(t => now - t < 60000);
  arr.push(now); hits.set(ip, arr); return arr.length > 10;
}

function productView(p) { const c = KK.calc(p); return Object.assign({}, p, { total: c.total, direct: c.direct, sharePercent: Math.round(c.share * 10) / 10, wageIndex: c.wageIndex }); }

async function api(req, res, url) {
  const parts = url.pathname.split("/").filter(Boolean).slice(1);   // after "api"
  if (req.method === "GET" && parts[0] === "artisans") return send(res, 200, KK.artisans);
  if (req.method === "GET" && parts[0] === "products" && !parts[1]) return send(res, 200, KK.products.map(productView));
  if (req.method === "GET" && parts[0] === "products" && parts[2] === "price") {
    const p = KK.byId(parts[1]); if (!p) return send(res, 404, { error: "Unknown product" });
    const size = KK.SIZES.find(s => s.id === url.searchParams.get("size")) || KK.SIZES[1];
    const qty = Math.max(1, Math.min(500, parseInt(url.searchParams.get("qty"), 10) || 1));
    return send(res, 200, KK.estimate(p, { f: size.f, qty }));
  }
  if (parts[0] === "inquiries") {
    if (req.method === "POST") {
      if (limited(req.socket.remoteAddress)) return send(res, 429, { error: "Too many requests. Please wait a minute." });
      let body; try { body = await readBody(req); } catch (e) { return send(res, e.code || 400, { error: e.message }); }
      const v = KK.validateInquiry(body);
      if (!v.ok) return send(res, 400, { errors: v.errors });
      const ref = "KK-" + crypto.randomBytes(3).toString("hex").toUpperCase();
      const list = readDb(); list.unshift(Object.assign({ ref, at: new Date().toISOString() }, v.clean)); writeDb(list.slice(0, 5000));
      return send(res, 201, { ref });
    }
    if (req.method === "GET") {
      const tok = process.env.ADMIN_TOKEN, auth = req.headers.authorization || "";
      const ok = tok && auth.length === ("Bearer " + tok).length && crypto.timingSafeEqual(Buffer.from(auth), Buffer.from("Bearer " + tok));
      if (!ok) return send(res, 401, { error: "Unauthorized" });
      return send(res, 200, readDb());
    }
  }
  return send(res, 404, { error: "Not found" });
}

function serveStatic(req, res, url) {
  let rel = decodeURIComponent(url.pathname).replace(/^\/+/, "") || "index.html";
  const top = rel.split("/")[0];
  const file = path.normalize(path.join(ROOT, rel));
  if (!PUBLIC.has(top) || !file.startsWith(ROOT + path.sep)) return send(res, 404, "Not found", "text/plain");
  fs.readFile(file, (err, data) => err ? send(res, 404, "Not found", "text/plain") : send(res, 200, data, MIME[path.extname(file)] || "application/octet-stream"));
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://localhost");
    if (url.pathname.startsWith("/api/")) return await api(req, res, url);
    if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, "Method not allowed", "text/plain");
    return serveStatic(req, res, url);
  } catch (e) { console.error(e); send(res, 500, { error: "Server error" }); }
});

if (require.main === module) server.listen(PORT, () => console.log("KalaKart running at http://localhost:" + PORT));
module.exports = server;
