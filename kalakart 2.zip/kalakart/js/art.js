/* Procedural SVG illustrations for crafts, technique icons and workshop panoramas.
   No external images are needed, so the site works offline. To use real photographs,
   set product.photo / artisan.panorama and swap the <img> in app.js.              */

window.KKArt = (function () {

  const bg = (uid, a, b) => `
    <defs>
      <linearGradient id="bg${uid}" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/>
      </linearGradient>
      <linearGradient id="sh${uid}" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0" stop-color="#000" stop-opacity=".25"/><stop offset=".5" stop-color="#fff" stop-opacity=".15"/><stop offset="1" stop-color="#000" stop-opacity=".25"/>
      </linearGradient>
    </defs>
    <rect width="400" height="400" fill="url(#bg${uid})"/>
    <circle cx="330" cy="70" r="120" fill="#fff" opacity=".25"/>`;

  const shadow = (cx, cy, rx) => `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${rx * 0.14}" fill="#2A1F1A" opacity=".18"/>`;

  function figure(x, y, s, c) {
    const [m, d] = c;
    let tex = "";
    for (let i = 0; i < 8; i++) tex += `<path d="M${-30} ${-20 + i * 12} Q0 ${-12 + i * 12} 30 ${-20 + i * 12}" stroke="${d}" stroke-width="2" fill="none" opacity=".55"/>`;
    return `<g transform="translate(${x} ${y}) scale(${s})">
      <rect x="-28" y="95" width="22" height="75" rx="9" fill="${m}"/><rect x="6" y="95" width="22" height="75" rx="9" fill="${m}"/>
      <path d="M-30 -20 Q0 -40 30 -20 L40 105 Q0 120 -40 105 Z" fill="${m}"/>
      ${tex}
      <path d="M-30 -10 Q-70 20 -62 78" stroke="${m}" stroke-width="16" stroke-linecap="round" fill="none"/>
      <path d="M30 -10 Q70 20 62 78" stroke="${m}" stroke-width="16" stroke-linecap="round" fill="none"/>
      <circle cx="0" cy="-52" r="26" fill="${m}"/>
      <path d="M-34 -62 Q0 -118 34 -62" stroke="${d}" stroke-width="12" fill="none" stroke-linecap="round"/>
      <path d="M-26 -72 Q0 -105 26 -72" stroke="${m}" stroke-width="7" fill="none" stroke-linecap="round" stroke-dasharray="3 5"/>
      <circle cx="-9" cy="-55" r="3" fill="${d}"/><circle cx="9" cy="-55" r="3" fill="${d}"/>
      <circle cx="0" cy="22" r="10" fill="none" stroke="${d}" stroke-width="3" opacity=".7"/>
    </g>`;
  }

  function wheel(x, y, r, c) {
    let spokes = "";
    for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; spokes += `<line x1="${x}" y1="${y}" x2="${x + r * Math.cos(a)}" y2="${y + r * Math.sin(a)}" stroke="${c[1]}" stroke-width="3"/>`; }
    return `<circle cx="${x}" cy="${y}" r="${r}" fill="none" stroke="${c[0]}" stroke-width="8"/>${spokes}<circle cx="${x}" cy="${y}" r="7" fill="${c[1]}"/>`;
  }

  const draw = {
    figurine: (c) => `${shadow(200, 352, 90)}${figure(200, 180, 1.35, c).replace("scale(1.35)", "scale(1.15)")}`,
    couple: (c) => `${shadow(200, 352, 150)}${figure(130, 190, 0.95, c)}${figure(270, 190, 0.95, [c[0], c[1]])}`,
    cart: (c) => `${shadow(200, 340, 150)}
      ${wheel(130, 290, 44, c)}${wheel(260, 290, 44, c)}
      <rect x="95" y="215" width="200" height="22" rx="6" fill="${c[0]}"/>
      <rect x="105" y="170" width="6" height="45" fill="${c[1]}"/><rect x="278" y="170" width="6" height="45" fill="${c[1]}"/>
      <path d="M100 170 H290" stroke="${c[1]}" stroke-width="6"/>
      <line x1="295" y1="225" x2="330" y2="245" stroke="${c[1]}" stroke-width="6"/>
      <ellipse cx="345" cy="240" rx="42" ry="26" fill="${c[0]}"/><circle cx="378" cy="228" r="16" fill="${c[0]}"/>
      <path d="M370 215 Q385 190 372 198 M388 218 Q405 196 392 205" stroke="${c[1]}" stroke-width="4" fill="none"/>
      <rect x="318" y="255" width="9" height="40" rx="3" fill="${c[1]}"/><rect x="355" y="255" width="9" height="40" rx="3" fill="${c[1]}"/>`,
    tops: (c) => [0, 1, 2].map(i => {
      const x = 110 + i * 90, y = 250 - (i === 1 ? 20 : 0), col = c[i % c.length];
      return `${shadow(x, 330, 38)}<rect x="${x - 4}" y="${y - 70}" width="8" height="40" rx="3" fill="${c[(i + 1) % c.length]}"/>
      <path d="M${x - 44} ${y - 20} Q${x - 44} ${y - 50} ${x} ${y - 50} Q${x + 44} ${y - 50} ${x + 44} ${y - 20} Q${x + 30} ${y + 50} ${x} ${y + 76} Q${x - 30} ${y + 50} ${x - 44} ${y - 20} Z" fill="${col}"/>
      <path d="M${x - 44} ${y - 20} Q${x} ${y - 4} ${x + 44} ${y - 20}" stroke="#fff" stroke-width="4" fill="none" opacity=".7"/>
      <path d="M${x - 36} ${y + 14} Q${x} ${y + 28} ${x + 36} ${y + 14}" stroke="${c[(i + 1) % c.length]}" stroke-width="5" fill="none"/>
      <ellipse cx="${x - 14}" cy="${y - 30}" rx="8" ry="5" fill="#fff" opacity=".35"/>`;
    }).join(""),
    rings: (c) => `${shadow(200, 352, 110)}<rect x="193" y="70" width="14" height="285" rx="6" fill="#8A6A45"/>` +
      [0, 1, 2, 3, 4, 5, 6].map(i => {
        const w = 110 - i * 11, y = 322 - i * 38;
        return `<ellipse cx="200" cy="${y}" rx="${w}" ry="22" fill="${c[i % c.length]}"/><ellipse cx="200" cy="${y - 5}" rx="${w - 8}" ry="12" fill="#fff" opacity=".18"/>`;
      }).join("") + `<circle cx="200" cy="58" r="20" fill="${c[0]}"/>`,
    box: (c) => `${shadow(200, 330, 130)}
      <ellipse cx="200" cy="290" rx="120" ry="32" fill="${c[0]}"/>
      <rect x="80" y="200" width="240" height="90" fill="${c[0]}"/>
      <rect x="80" y="225" width="240" height="14" fill="${c[1]}"/><rect x="80" y="255" width="240" height="8" fill="${c[2]}"/>
      <ellipse cx="200" cy="200" rx="120" ry="32" fill="${c[0]}"/>
      <ellipse cx="200" cy="175" rx="112" ry="28" fill="${c[0]}"/><rect x="88" y="175" width="224" height="30" fill="${c[0]}"/>
      <ellipse cx="200" cy="175" rx="112" ry="28" fill="${c[2]}" opacity=".35"/>
      <ellipse cx="200" cy="165" rx="20" ry="8" fill="${c[1]}"/>`,
    bidrivase: (c) => {
      let lat = "";
      for (let i = -3; i < 12; i++) lat += `<path d="M${100 + i * 28} 80 L${170 + i * 28} 340 M${300 - i * 28} 80 L${230 - i * 28} 340" stroke="${c[1]}" stroke-width="2.2" opacity=".9"/>`;
      let dots = "";
      for (let y = 110; y < 330; y += 36) dots += `<circle cx="200" cy="${y}" r="5" fill="${c[1]}"/><circle cx="${150 + Math.sin(y) * 4}" cy="${y + 18}" r="3" fill="${c[1]}"/>`;
      return `${shadow(200, 350, 90)}<defs><clipPath id="vc"><path id="vp" d="M165 70 H235 L232 100 Q300 150 290 240 Q285 320 250 345 H150 Q115 320 110 240 Q100 150 168 100 Z"/></clipPath></defs>
      <path d="M165 70 H235 L232 100 Q300 150 290 240 Q285 320 250 345 H150 Q115 320 110 240 Q100 150 168 100 Z" fill="${c[0]}"/>
      <g clip-path="url(#vc)">${lat}${dots}</g>
      <rect x="160" y="66" width="80" height="8" rx="4" fill="${c[1]}"/><rect x="146" y="338" width="108" height="10" rx="4" fill="${c[1]}"/>
      <path d="M135 150 Q125 240 140 310" stroke="#fff" stroke-width="5" opacity=".18" fill="none"/>`;
    },
    bidribox: (c) => {
      let star = "";
      for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; star += `<line x1="200" y1="190" x2="${200 + 50 * Math.cos(a)}" y2="${190 + 22 * Math.sin(a)}" stroke="${c[1]}" stroke-width="2"/>`; }
      return `${shadow(200, 320, 130)}
      <path d="M70 200 L130 150 H330 L270 200 Z" fill="#2c3238"/>
      <rect x="70" y="200" width="200" height="110" fill="${c[0]}"/><path d="M270 200 L330 150 V260 L270 310 Z" fill="#14181c"/>
      ${star}<ellipse cx="200" cy="190" rx="36" ry="14" fill="none" stroke="${c[1]}" stroke-width="2"/>
      <path d="M80 215 H260 M80 295 H260" stroke="${c[1]}" stroke-width="2"/>
      <path d="M90 240 q15 -14 30 0 t30 0 t30 0 t30 0" stroke="${c[1]}" fill="none" stroke-width="2.2"/>
      <path d="M90 270 q15 -14 30 0 t30 0 t30 0 t30 0" stroke="${c[1]}" fill="none" stroke-width="2.2"/>`;
    },
    pendant: (c) => `${shadow(200, 360, 90)}
      <path d="M90 60 Q200 330 310 60" stroke="${c[1]}" stroke-width="3" fill="none" stroke-dasharray="1 6" stroke-linecap="round"/>
      <circle cx="200" cy="236" r="54" fill="${c[0]}"/>
      ${[0, 1, 2, 3, 4, 5, 6, 7].map(i => { const a = i * Math.PI / 4; return `<ellipse cx="${200 + 26 * Math.cos(a)}" cy="${236 + 26 * Math.sin(a)}" rx="10" ry="5" transform="rotate(${i * 45} ${200 + 26 * Math.cos(a)} ${236 + 26 * Math.sin(a)})" fill="${c[1]}"/>`; }).join("")}
      <circle cx="200" cy="236" r="9" fill="${c[1]}"/><circle cx="200" cy="236" r="46" fill="none" stroke="${c[1]}" stroke-width="2"/>
      <circle cx="115" cy="320" r="24" fill="${c[0]}"/><circle cx="115" cy="320" r="12" fill="none" stroke="${c[1]}" stroke-width="2"/>
      <circle cx="285" cy="320" r="24" fill="${c[0]}"/><circle cx="285" cy="320" r="12" fill="none" stroke="${c[1]}" stroke-width="2"/>`,
    saree: (c) => {
      let d = "";
      for (let i = 0; i < 6; i++) for (let j = 0; j < 5; j++) d += `<path d="M${90 + i * 42} ${100 + j * 54} l12 12 l-12 12 l-12 -12 z" fill="${c[2]}" opacity=".9"/><path d="M${111 + i * 42} ${126 + j * 54} l7 7 l-7 7 l-7 -7 z" fill="${c[1]}" opacity=".9"/>`;
      return `${shadow(200, 372, 140)}
      <path d="M70 60 Q200 30 330 60 L350 340 Q200 375 50 340 Z" fill="${c[0]}"/>
      ${d}
      <path d="M70 60 Q200 30 330 60" stroke="${c[2]}" stroke-width="12" fill="none"/>
      <path d="M50 340 Q200 375 350 340" stroke="${c[2]}" stroke-width="14" fill="none"/><path d="M50 322 Q200 357 350 322" stroke="${c[1]}" stroke-width="4" fill="none"/>
      <path d="M120 40 Q150 200 100 350" stroke="#000" stroke-opacity=".12" stroke-width="22" fill="none"/>
      <path d="M260 40 Q240 190 280 355" stroke="#fff" stroke-opacity=".14" stroke-width="22" fill="none"/>
      ${Array.from({ length: 16 }, (_, i) => `<line x1="${62 + i * 18}" y1="345" x2="${60 + i * 18}" y2="372" stroke="${c[2]}" stroke-width="3"/>`).join("")}`;
    },
    dupatta: (c) => {
      let d = "";
      for (let j = 0; j < 9; j++) d += `<path d="M${200 + Math.sin(j) * 20} ${70 + j * 30} l10 10 l-10 10 l-10 -10 z" fill="${c[2]}"/><circle cx="${150 + (j % 2) * 100}" cy="${90 + j * 30}" r="5" fill="${c[1]}"/>`;
      return `${shadow(200, 376, 110)}<path d="M110 50 Q200 30 290 50 L300 340 Q200 370 100 340 Z" fill="${c[0]}"/>
      <rect x="110" y="50" width="12" height="290" fill="${c[1]}" opacity=".7"/><rect x="278" y="50" width="12" height="290" fill="${c[1]}" opacity=".7"/>${d}
      <path d="M100 340 Q200 370 300 340" stroke="${c[2]}" stroke-width="12" fill="none"/>
      ${Array.from({ length: 12 }, (_, i) => `<line x1="${104 + i * 17}" y1="345" x2="${104 + i * 17}" y2="372" stroke="${c[1]}" stroke-width="3"/>`).join("")}`;
    },
    stole: (c) => {
      let d = "";
      for (let i = 0; i < 12; i++) d += `<path d="M${80 + i * 22} ${200 + (i % 2) * 14} l8 8 l-8 8 l-8 -8 z" fill="${c[2]}"/>`;
      return `${shadow(200, 340, 140)}<path d="M40 150 Q200 110 360 150 L360 250 Q200 290 40 250 Z" fill="${c[0]}"/>
      <path d="M40 150 Q200 110 360 150" stroke="${c[2]}" stroke-width="10" fill="none"/><path d="M40 250 Q200 290 360 250" stroke="${c[2]}" stroke-width="10" fill="none"/>${d}
      ${Array.from({ length: 16 }, (_, i) => `<line x1="${44 + i * 20}" y1="${160 + Math.sin(i / 2) * 3}" x2="${44 + i * 20}" y2="${150}" stroke="${c[2]}"/>`).join("")}
      <path d="M40 150 L25 175 M40 250 L25 225 M360 150 L375 175 M360 250 L375 225" stroke="${c[2]}" stroke-width="4"/>`;
    },
    necklace: (c) => {
      let links = "";
      for (let i = 0; i <= 14; i++) {
        const t = i / 14, x = 60 + t * 280, y = 100 + 200 * Math.pow(2 * t - 1, 2) * -1 + 200;
        links += `<circle cx="${x}" cy="${y}" r="${i % 3 === 0 ? 17 : 11}" fill="none" stroke="${c[0]}" stroke-width="${i % 3 === 0 ? 8 : 6}"/>${i % 3 === 0 ? `<circle cx="${x}" cy="${y}" r="5" fill="${c[1]}"/>` : ""}`;
      }
      return `${shadow(200, 350, 100)}${links}<path d="M60 200 Q30 120 80 70 M340 200 Q370 120 320 70" stroke="#2A1F1A" stroke-width="3" fill="none" stroke-dasharray="2 6"/>`;
    },
    jhumka: (c) => [120, 280].map(x => `${shadow(x, 350, 45)}
      <circle cx="${x}" cy="70" r="14" fill="${c[0]}"/><path d="M${x} 84 v30" stroke="${c[0]}" stroke-width="6"/>
      <path d="M${x - 50} 200 Q${x - 50} 110 ${x} 110 Q${x + 50} 110 ${x + 50} 200 Z" fill="${c[0]}"/>
      ${[0, 1, 2, 3].map(i => `<path d="M${x - 40 + i * 4} ${135 + i * 14} Q${x} ${125 + i * 14} ${x + 40 - i * 4} ${135 + i * 14}" stroke="${c[1]}" stroke-width="3" fill="none"/>`).join("")}
      ${Array.from({ length: 7 }, (_, i) => `<line x1="${x - 48 + i * 16}" y1="200" x2="${x - 48 + i * 16}" y2="${222 + (i % 2) * 12}" stroke="${c[0]}" stroke-width="4"/><circle cx="${x - 48 + i * 16}" cy="${226 + (i % 2) * 12}" r="6" fill="${c[0]}"/>`).join("")}`).join(""),
    lamp: (c) => `${shadow(200, 360, 110)}
      <path d="M90 300 Q200 350 310 300 L290 330 Q200 360 110 330 Z" fill="${c[1]}"/>
      <path d="M100 300 Q200 270 300 300 Q200 345 100 300 Z" fill="${c[0]}"/>
      <rect x="190" y="130" width="20" height="150" rx="8" fill="${c[0]}"/>
      <path d="M150 160 Q200 70 250 160 Z" fill="${c[0]}"/><circle cx="200" cy="98" r="22" fill="${c[0]}"/>
      <path d="M150 205 Q200 235 250 205" stroke="${c[1]}" stroke-width="5" fill="none"/>
      <path d="M60 250 Q75 190 120 190 L140 205 Q80 210 90 260 Z" fill="${c[0]}"/><ellipse cx="75" cy="250" rx="28" ry="14" fill="${c[0]}"/>
      <path d="M72 210 Q58 175 80 158 Q80 190 98 196 Q94 220 72 210 Z" fill="#F2A33C"/>`,
    plate: (c) => {
      let petals = "";
      for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5; petals += `<ellipse cx="${200 + 112 * Math.cos(a)}" cy="${200 + 112 * Math.sin(a)}" rx="20" ry="9" transform="rotate(${i * 36} ${200 + 112 * Math.cos(a)} ${200 + 112 * Math.sin(a)})" fill="${c[0]}"/>`; }
      let inner = "";
      for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; inner += `<ellipse cx="${200 + 40 * Math.cos(a)}" cy="${200 + 40 * Math.sin(a)}" rx="26" ry="11" transform="rotate(${i * 60} ${200 + 40 * Math.cos(a)} ${200 + 40 * Math.sin(a)})" fill="${c[2]}"/>`; }
      return `${shadow(200, 372, 130)}<circle cx="200" cy="200" r="150" fill="#fff"/><circle cx="200" cy="200" r="150" fill="none" stroke="${c[0]}" stroke-width="8"/>
      <circle cx="200" cy="200" r="132" fill="none" stroke="${c[2]}" stroke-width="2"/>${petals}${inner}<circle cx="200" cy="200" r="14" fill="${c[0]}"/>
      <circle cx="200" cy="200" r="86" fill="none" stroke="${c[0]}" stroke-width="2" stroke-dasharray="3 6"/>`;
    },
    bpvase: (c) => `${shadow(200, 360, 90)}
      <path d="M165 60 H235 L232 105 Q310 150 300 250 Q290 330 245 350 H155 Q110 330 100 250 Q90 150 168 105 Z" fill="#fff"/>
      <path d="M165 60 H235 L232 105 Q310 150 300 250 Q290 330 245 350 H155 Q110 330 100 250 Q90 150 168 105 Z" fill="none" stroke="${c[0]}" stroke-width="5"/>
      <rect x="160" y="56" width="80" height="12" rx="5" fill="${c[0]}"/>
      <path d="M120 170 Q200 210 280 170" stroke="${c[0]}" stroke-width="4" fill="none"/><path d="M110 300 Q200 330 290 300" stroke="${c[0]}" stroke-width="4" fill="none"/>
      ${[0, 1, 2].map(i => `<ellipse cx="${150 + i * 50}" cy="${245 - (i === 1 ? 20 : 0)}" rx="17" ry="8" transform="rotate(${i * 60 - 30} ${150 + i * 50} ${245 - (i === 1 ? 20 : 0)})" fill="${c[0]}"/><circle cx="${150 + i * 50}" cy="${245 - (i === 1 ? 20 : 0)}" r="5" fill="${c[2]}"/>`).join("")}
      <path d="M130 240 Q200 190 270 240" stroke="${c[2]}" stroke-width="3" fill="none"/>`,
    camel: (c) => `${shadow(200, 345, 130)}
      <ellipse cx="190" cy="220" rx="90" ry="48" fill="${c[0]}"/><ellipse cx="170" cy="170" rx="32" ry="32" fill="${c[0]}"/><ellipse cx="225" cy="168" rx="28" ry="30" fill="${c[0]}"/>
      <path d="M262 200 Q310 120 318 82" stroke="${c[0]}" stroke-width="36" stroke-linecap="round" fill="none"/>
      <ellipse cx="338" cy="78" rx="34" ry="20" fill="${c[0]}"/><circle cx="332" cy="70" r="4" fill="${c[1]}"/>
      <rect x="120" y="245" width="18" height="90" rx="8" fill="${c[1]}"/><rect x="160" y="250" width="18" height="85" rx="8" fill="${c[0]}"/>
      <rect x="215" y="250" width="18" height="85" rx="8" fill="${c[0]}"/><rect x="250" y="245" width="18" height="90" rx="8" fill="${c[1]}"/>
      <path d="M130 190 Q200 150 250 190 L250 225 Q190 245 130 225 Z" fill="${c[1]}" opacity=".85"/>
      <path d="M140 200 H245 M140 214 H245" stroke="#F1E3C4" stroke-width="3" stroke-dasharray="5 5"/>
      <path d="M100 215 Q85 230 92 260" stroke="${c[1]}" stroke-width="6" fill="none"/>`
  };

  const palettes = {
    dhokra: ["#F3E4C3", "#E4C58E"], channapatna: ["#F4E9D2", "#F0C9A0"], bidri: ["#EBE7DF", "#BFC4C8"],
    ikat: ["#F5E6E6", "#E8C9CF"], bluepottery: ["#EAF1F7", "#C9DDEC"], terracotta: ["#F6E4D2", "#E8BF9B"]
  };

  function product(p, uid) {
    const pal = palettes[p.craft] || ["#F4E9D2", "#E8CFA8"];
    const f = draw[p.art] || draw.figurine;
    return `<svg viewBox="0 0 400 400" role="img" aria-label="Illustration of ${p.name}" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">${bg(uid, pal[0], pal[1])}${f(p.c)}</svg>`;
  }

  /* Small icons (24x24, stroke) */
  const icons = {
    mound: "M3 19c2-9 16-9 18 0zM2 19h20",
    coil: "M12 12h.01M8 12a4 4 0 1 1 4 4M4 12a8 8 0 1 1 8 8",
    shield: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z",
    flame: "M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3 0-6 1-9z",
    sparkle: "M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 17l.8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8z",
    brush: "M18 3l3 3-9 9-3-3zM9 12c-3 0-4 2-4 4s-1 3-2 4c3 1 8 0 8-4",
    play: "M7 4v16l13-8z",
    pause: "M6 4h4v16H6zM14 4h4v16h-4z",
    check: "M4 12l5 5L20 6",
    shieldCheck: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6zM8.5 12l2.5 2.5L16 9.5",
    map: "M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11zM12 12a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z",
    user: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21c0-4 4-6 8-6s8 2 8 6",
    left: "M15 5l-7 7 7 7",
    right: "M9 5l7 7-7 7",
    mic: "M12 14a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v5a3 3 0 0 0 3 3zM5 11a7 7 0 0 0 14 0M12 18v3",
    send: "M22 2L11 13M22 2l-7 20-4-9-9-4z",
    clock: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3 2",
    rupee: "M7 5h10M7 9h10M7 5c6 0 7 7 0 7h-1l7 7",
    heart: "M12 21s-8-5.2-8-11a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 20 10c0 5.8-8 11-8 11z",
    cube: "M12 3l8 4.5v9L12 21l-8-4.5v-9zM12 12l8-4.5M12 12v9M12 12L4 7.5"
  };
  function icon(name, size) {
    return `<svg class="ico" width="${size || 20}" height="${size || 20}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${icons[name] || icons.sparkle}"/></svg>`;
  }

  /* ---------- Workshop panorama (1800 x 420, seamless horizontally) ---------- */
  const PW = 1800, PH = 420;
  function panorama(kind, accent) {
    const beams = Array.from({ length: 6 }, (_, i) => `<rect x="${i * 300 + 20}" y="0" width="14" height="300" fill="#6b4a2e" opacity=".55"/>`).join("");
    const win = [150, 1050].map(x => `<rect x="${x}" y="70" width="120" height="130" rx="6" fill="#FFE9B8"/><rect x="${x}" y="70" width="120" height="130" rx="6" fill="none" stroke="#6b4a2e" stroke-width="8"/><path d="M${x + 60} 70 V200 M${x} 135 H${x + 120}" stroke="#6b4a2e" stroke-width="5"/><path d="M${x - 20} 320 L${x + 40} 200 H${x + 120} L${x + 180} 320 Z" fill="#FFF3C9" opacity=".25"/>`).join("");
    const floor = `<rect y="300" width="${PW}" height="120" fill="#a9825c"/><rect y="300" width="${PW}" height="10" fill="#8b6743"/>` +
      Array.from({ length: 30 }, (_, i) => `<line x1="${i * 60}" y1="310" x2="${i * 60 - 40}" y2="420" stroke="#8b6743" opacity=".5"/>`).join("");
    const table = (x, w) => `<rect x="${x - w / 2}" y="250" width="${w}" height="14" fill="#6b4a2e"/><rect x="${x - w / 2 + 8}" y="264" width="10" height="56" fill="#563a22"/><rect x="${x + w / 2 - 18}" y="264" width="10" height="56" fill="#563a22"/>`;
    const props = {
      furnace: [
        x => `${table(x, 220)}${[0, 1, 2, 3].map(i => `<ellipse cx="${x - 80 + i * 55}" cy="244" rx="20" ry="7" fill="#E8C98A"/>`).join("")}<circle cx="${x + 80}" cy="226" r="22" fill="#B5753A"/>`,
        x => `<ellipse cx="${x}" cy="318" rx="90" ry="26" fill="#3b2a1e"/><ellipse cx="${x}" cy="312" rx="70" ry="18" fill="#c8431a"/><path d="M${x - 40} 305 Q${x - 20} 230 ${x} 270 Q${x + 10} 220 ${x + 30} 260 Q${x + 50} 230 ${x + 45} 305 Z" fill="#F2A33C"/><path d="M${x - 20} 305 Q${x} 250 ${x + 20} 305 Z" fill="#FFE27A"/><circle cx="${x}" cy="200" r="90" fill="#F2A33C" opacity=".12"/>`,
        x => `<rect x="${x - 120}" y="150" width="240" height="8" fill="#6b4a2e"/><rect x="${x - 120}" y="220" width="240" height="8" fill="#6b4a2e"/>${[0, 1, 2, 3, 4].map(i => `<ellipse cx="${x - 90 + i * 45}" cy="136" rx="16" ry="20" fill="#9a6b45"/><ellipse cx="${x - 90 + i * 45}" cy="206" rx="16" ry="20" fill="#8a5b38"/>`).join("")}<rect x="${x - 120}" y="150" width="8" height="170" fill="#6b4a2e"/><rect x="${x + 112}" y="150" width="8" height="170" fill="#6b4a2e"/>`
      ],
      lathe: [
        x => `${[0, 1, 2].map(i => `<rect x="${x - 90 + i * 8}" y="${290 - i * 22}" width="170" height="20" rx="10" fill="#9a6b45" stroke="#6b4a2e"/>`).join("")}<rect x="${x - 70}" y="224" width="130" height="20" rx="10" fill="#b07c50" stroke="#6b4a2e"/>`,
        x => `<rect x="${x - 130}" y="230" width="260" height="14" fill="#4a3a2e"/><rect x="${x - 120}" y="244" width="12" height="76" fill="#4a3a2e"/><rect x="${x + 108}" y="244" width="12" height="76" fill="#4a3a2e"/><rect x="${x - 80}" y="190" width="30" height="40" fill="#6b4a2e"/><ellipse cx="${x}" cy="210" rx="14" ry="30" fill="${accent}"/><ellipse cx="${x}" cy="210" rx="8" ry="30" fill="#fff" opacity=".2"/><rect x="${x + 50}" y="205" width="70" height="8" fill="#9aa3ab"/>`,
        x => `${table(x, 220)}${["#C94C32", "#2B3A67", "#E8B93E", "#2E7D6B", "#7A2E4B"].map((c, i) => `<rect x="${x - 90 + i * 36}" y="220" width="12" height="30" rx="3" fill="${c}"/>`).join("")}`
      ],
      loom: [
        x => `<rect x="${x - 100}" y="140" width="10" height="180" fill="#6b4a2e"/><rect x="${x + 90}" y="140" width="10" height="180" fill="#6b4a2e"/><rect x="${x - 100}" y="140" width="200" height="8" fill="#6b4a2e"/>${[0, 1, 2, 3, 4].map(i => `<path d="M${x - 80 + i * 40} 148 q-10 70 0 140" stroke="${["#7A2E4B", "#C9A13B", "#2B3A67", "#C94C32", "#2E7D6B"][i]}" stroke-width="12" fill="none"/>`).join("")}`,
        x => `<rect x="${x - 120}" y="170" width="240" height="10" fill="#6b4a2e"/><rect x="${x - 120}" y="170" width="10" height="150" fill="#6b4a2e"/><rect x="${x + 110}" y="170" width="10" height="150" fill="#6b4a2e"/>${Array.from({ length: 24 }, (_, i) => `<line x1="${x - 105 + i * 9.5}" y1="180" x2="${x - 105 + i * 9.5}" y2="290" stroke="${i % 6 < 3 ? accent : "#F1E3C4"}" stroke-width="3"/>`).join("")}<rect x="${x - 118}" y="276" width="236" height="22" fill="${accent}" opacity=".85"/><rect x="${x - 60}" y="300" width="120" height="14" rx="4" fill="#4a3a2e"/>`,
        x => `${table(x, 240)}<rect x="${x - 100}" y="214" width="200" height="36" fill="${accent}"/><path d="M${x - 100} 250 v16 M${x - 80} 250 v16 M${x - 60} 250 v16 M${x - 40} 250 v16 M${x - 20} 250 v16 M${x} 250 v16 M${x + 20} 250 v16 M${x + 40} 250 v16 M${x + 60} 250 v16 M${x + 80} 250 v16 M${x + 100} 250 v16" stroke="#F1E3C4" stroke-width="3"/>`
      ],
      wheel: [
        x => `${table(x, 220)}<ellipse cx="${x - 40}" cy="242" rx="42" ry="12" fill="#e8e0d0"/><ellipse cx="${x + 50}" cy="244" rx="24" ry="9" fill="#d9d1c2"/>`,
        x => `<path d="M${x - 70} 320 L${x - 20} 160 L${x + 30} 160 L${x + 80} 320" stroke="#6b4a2e" stroke-width="10" fill="none"/><circle cx="${x + 5}" cy="190" r="48" fill="#fff" stroke="${accent}" stroke-width="8"/><circle cx="${x + 5}" cy="190" r="30" fill="none" stroke="${accent}" stroke-width="3"/><path d="M${x - 15} 190 h40 M${x + 5} 170 v40" stroke="${accent}" stroke-width="3"/>`,
        x => `<path d="M${x - 100} 320 V240 Q${x - 100} 150 ${x} 150 Q${x + 100} 150 ${x + 100} 240 V320 Z" fill="#b5532f"/><rect x="${x - 36}" y="250" width="72" height="70" rx="26" fill="#2A1F1A"/><circle cx="${x}" cy="285" r="18" fill="#F2A33C" opacity=".7"/>`
      ]
    };
    const set = props[kind] || props.furnace;
    const xs = [330, 890, 1400];
    return `<svg viewBox="0 0 ${PW} ${PH}" width="${PW}" height="${PH}" xmlns="http://www.w3.org/2000/svg">
      <defs><linearGradient id="wall${kind}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#EAD4AE"/><stop offset="1" stop-color="#D6B98B"/></linearGradient></defs>
      <rect width="${PW}" height="300" fill="url(#wall${kind})"/>${beams}${win}${floor}
      ${set.map((fn, i) => fn(xs[i])).join("")}
      <rect width="${PW}" height="${PH}" fill="url(#wall${kind})" opacity="0"/>
    </svg>`;
  }

  /* simple India outline (lon/lat) for the village cluster map */
  const outline = [[74, 37], [77, 35.5], [79, 34], [78.5, 32], [81, 30], [80, 28.7], [84, 27.5], [88, 27], [88.6, 26.4], [89.8, 26.7], [92, 27], [95, 28.5], [97, 28], [96, 27], [95, 26], [94, 24], [93, 22.5], [92.4, 22], [92, 24], [91, 25.2], [89.8, 25.3], [89, 26], [88.5, 24.5], [89, 22], [87, 21.5], [86.5, 20], [85, 19.2], [84, 18], [82.3, 16.5], [80.3, 15.5], [80, 13.5], [80.3, 11], [79.3, 10], [78, 8.5], [77.5, 8.1], [76.5, 9], [75.5, 11.5], [74.8, 13], [74, 15.5], [73, 17.5], [72.8, 19.5], [72.5, 21], [70.5, 20.8], [69, 22.3], [70, 22.8], [68.2, 23.6], [69, 24.2], [70.5, 24.2], [71, 25], [70, 26], [70.5, 27.8], [72, 28.5], [72, 30], [74.5, 31], [74, 32.5], [74.5, 34.5]];
  function indiaMap(pins, activeId) {
    const s = 17, x = lon => (lon - 67) * s, y = lat => (38 - lat) * s;
    const pts = outline.map(p => x(p[0]).toFixed(1) + "," + y(p[1]).toFixed(1)).join(" ");
    return `<svg viewBox="0 0 ${(98 - 67) * s} ${(38 - 7) * s}" role="img" aria-label="Map of artisan villages" xmlns="http://www.w3.org/2000/svg">
      <polygon points="${pts}" fill="#EAD7B3" stroke="#B89865" stroke-width="2" stroke-linejoin="round"/>
      ${pins.map(a => `<g class="pin ${a.id === activeId ? "on" : ""}" data-artisan="${a.id}" tabindex="0" role="link" aria-label="${a.name}, ${a.village}">
        <circle cx="${x(a.lon)}" cy="${y(a.lat)}" r="16" fill="${a.color}" opacity=".18"/><circle cx="${x(a.lon)}" cy="${y(a.lat)}" r="7" fill="${a.color}" stroke="#fff" stroke-width="2"/>
        <text x="${x(a.lon) + 12}" y="${y(a.lat) + 4}" font-size="13" font-weight="600" fill="#2A1F1A" paint-order="stroke" stroke="#F6EEDF" stroke-width="4">${a.village.split(",")[0]}</text></g>`).join("")}
    </svg>`;
  }

  return { product, icon, panorama, indiaMap, PW };
})();
