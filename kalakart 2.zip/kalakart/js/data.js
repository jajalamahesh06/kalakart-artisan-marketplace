/* KalaKart sample dataset — 6 master artisans, 18 crafts.
   All names, stories and figures are SAMPLE DATA for the hackathon demo
   (except the Dhokra figurine numbers, which follow the problem brief).      */

/* Works in the browser (window.KK) and in Node (globalThis.KK) so the same
   calculation code is shared by the UI, the optional server and the unit tests. */
(typeof window !== "undefined" ? window : globalThis).KK = (typeof window !== "undefined" ? window : globalThis).KK || {};

/* Illustrative fair-wage benchmark (Rs per craft hour) used for the Fair-Wage Index. */
KK.BENCHMARK_RATE = 60;
/* Platform promise: artisans keep at least this share of the retail price. */
KK.MIN_SHARE = 75;

KK.artisans = [
  {
    id: "somu-baghel",
    name: "Somu Baghel",
    initials: "SB",
    craft: "Dhokra Brass Casting",
    village: "Kondagaon",
    district: "Bastar",
    state: "Chhattisgarh",
    lon: 81.66, lat: 19.59,
    coop: "Bastar Dhokra Shilpi Samooh",
    generation: 4,
    since: 1998,
    members: 42,
    color: "#B5462B",
    gi: { name: "Dhokra (Bastar) lost-wax brass craft", status: "Sample record", id: "DEMO-GI-CG-0114", year: "—" },
    story: "Somu learned to read wax the way others read letters. His great-grandfather cast ritual figures for tribal village deities; today Somu leads a cooperative of 42 Ghadwa and Gond craftspeople who still use the same non-ferrous lost-wax method, where every casting destroys its own mould, so no two pieces are ever identical.",
    lineage: [
      ["1920s", "Great-grandfather casts deity figures and bell-metal votive pieces for village ceremonies."],
      ["1960s", "Grandfather begins carrying small figurines to weekly haat markets at Jagdalpur."],
      ["1998", "Somu starts his own workshop in Kondagaon after 12 years as an apprentice."],
      ["2016", "Founds the cooperative so members can buy brass in bulk and sell without middlemen."]
    ],
    quote: "Every figure is made once. When the mould breaks, the piece is born.",
    audio: [
      { lang: "hi-IN", label: "Hindi", text: "नमस्ते, मैं सोमू बघेल हूँ, बस्तर से। हम ढोकरा में लॉस्ट वैक्स विधि से पीतल ढालते हैं। पहले मिट्टी का ढांचा बनता है, उस पर मोम के धागे लपेटते हैं, फिर मिट्टी की परत चढ़ाकर आग में पिघला पीतल डालते हैं।", en: "Hello, I am Somu Baghel from Bastar. In Dhokra we cast brass by the lost-wax method. First a clay core, then wax threads wound over it, then layers of clay, and finally molten brass is poured in the fire." }
    ],
    studio: "furnace",
    hotspots: [
      { x: 330, label: "Clay & wax table", text: "Wax threads are rolled by hand from beeswax and sal resin and coiled over the clay core." },
      { x: 900, label: "Brass furnace", text: "Scrap brass melts at nearly 1,000 °C in a husk-fired pit furnace before it is poured." },
      { x: 1400, label: "Drying racks", text: "Clay-coated moulds dry in the shade for 2–3 days before firing." }
    ]
  },
  {
    id: "rukmini-gowda",
    name: "Rukmini Gowda",
    initials: "RG",
    craft: "Channapatna Lacquer Woodwork",
    village: "Channapatna",
    district: "Ramanagara",
    state: "Karnataka",
    lon: 77.21, lat: 12.65,
    coop: "Channapatna Mahila Toy Makers",
    generation: 3,
    since: 2004,
    members: 58,
    color: "#2B3A67",
    gi: { name: "Channapatna Toys & Dolls", status: "Registered GI (Karnataka)", id: "DEMO-GI-KA-0206", year: "2006" },
    story: "Known as the 'toy town' of Karnataka, Channapatna turns local wood into lacquered toys using vegetable-based colours. Rukmini took over her father's lathe at 19 and now trains women from nearby villages in lac turning, a craft once left to men.",
    lineage: [
      ["1850s", "Craft is said to date to the court of Tipu Sultan, who invited Persian artisans to teach wood turning."],
      ["1970s", "Rukmini's father switches to non-toxic lac colours as the town adapts to new markets."],
      ["2004", "Rukmini begins turning full time and opens a workshop open to women."],
      ["2019", "Her group begins direct online orders and fair-wage tracking."]
    ],
    quote: "The lac melts from the heat of my own hands and the spinning wood. That is why it shines.",
    audio: [
      { lang: "hi-IN", label: "Hindi", text: "नमस्ते, मैं रुक्मिणी गौड़ा हूँ, चन्नपटना से। हम लकड़ी को खराद पर घुमाते हैं और लाख की छड़ से रंग चढ़ाते हैं। रंग पौधों से बनते हैं और खिलौने बच्चों के लिए सुरक्षित होते हैं।", en: "Hello, I am Rukmini Gowda from Channapatna. We turn wood on a lathe and colour it with lac sticks. The colours come from plants, so the toys are safe for children." }
    ],
    studio: "lathe",
    hotspots: [
      { x: 360, label: "Wood store", text: "Local wood is seasoned for months before it is cut into blanks." },
      { x: 880, label: "Hand lathe", text: "A bow-driven or motor lathe spins the wood while hand-held tools shape it." },
      { x: 1380, label: "Lac colour bench", text: "Lac sticks melt by friction against the spinning wood, coating it in colour." }
    ]
  },
  {
    id: "basavaraj-kamble",
    name: "Basavaraj Kamble",
    initials: "BK",
    craft: "Bidriware Silver Inlay",
    village: "Bidar",
    district: "Bidar",
    state: "Karnataka",
    lon: 77.52, lat: 17.91,
    coop: "Bidar Bidri Kala Sangha",
    generation: 5,
    since: 1994,
    members: 27,
    color: "#1E2A47",
    gi: { name: "Bidriware", status: "Registered GI (Karnataka)", id: "DEMO-GI-KA-0087", year: "2006" },
    story: "Bidriware travelled from Persia to the Deccan in the 14th century and found its home in Bidar. Basavaraj engraves each design by hand, presses silver into the grooves, then blackens the alloy with soil taken from inside Bidar Fort, a secret that gives the metal its velvet-dark finish.",
    lineage: [
      ["14th c.", "Bahmani court brings metal inlay artisans to Bidar."],
      ["1930s", "Great-grandfather becomes a court-supported engraver."],
      ["1994", "Basavaraj opens his own workshop after a decade of apprenticeship."],
      ["2010", "Begins training young apprentices through a cooperative school."]
    ],
    quote: "Black metal, white silver. The beauty is in the contrast and in the patience.",
    audio: [
      { lang: "hi-IN", label: "Hindi", text: "नमस्ते, मैं बसवराज कांबले हूँ, बीदर से। बिदरी में जस्ते और तांबे का मिश्रण ढालकर उस पर चांदी की नक्काशी भरते हैं। बीदर किले की खास मिट्टी से धातु काली होती है और चांदी चमक उठती है।", en: "Hello, I am Basavaraj Kamble from Bidar. In Bidri we cast a zinc and copper alloy and fill the engraving with silver. Soil from Bidar Fort turns the metal black and makes the silver glow." }
    ],
    studio: "furnace",
    hotspots: [
      { x: 340, label: "Casting corner", text: "The zinc-copper alloy is poured into sand moulds." },
      { x: 880, label: "Engraving bench", text: "Designs are engraved freehand with chisels the artisan has made himself." },
      { x: 1400, label: "Blackening station", text: "A paste with Bidar Fort soil and ammonium chloride blackens the alloy in seconds." }
    ]
  },
  {
    id: "kamala-meher",
    name: "Kamala Meher",
    initials: "KM",
    craft: "Sambalpuri Ikat Silk Handloom",
    village: "Barpali",
    district: "Bargarh",
    state: "Odisha",
    lon: 83.58, lat: 21.22,
    coop: "Barpali Bandha Weavers Cooperative",
    generation: 6,
    since: 1999,
    members: 90,
    color: "#7A2E4B",
    gi: { name: "Sambalpuri Bandha / Ikat", status: "Registered GI (Odisha)", id: "DEMO-GI-OD-0042", year: "2007" },
    story: "In Sambalpuri ikat the pattern is tied and dyed into the threads before weaving, so the weaver must hold the entire design in memory. Kamala's family has woven the shankha, chakra and phula motifs for six generations, and her cooperative of 90 weavers earns directly from every sale.",
    lineage: [
      ["Pre-1900", "Bhulia weavers of western Odisha refine tie-and-dye weaving."],
      ["1950s", "Her grandmother's loom produces the first saree in the family's signature chakra motif."],
      ["1999", "Kamala takes over the family loom and starts dyeing with fast natural pigments."],
      ["2015", "Cooperative moves to direct-to-buyer sales."]
    ],
    quote: "The design is in the thread before the cloth exists.",
    audio: [
      { lang: "or-IN", label: "Odia", text: "ନମସ୍କାର, ମୁଁ କମଳା ମେହେର। ଆମେ ସମ୍ବଲପୁରୀ ଇକତ ବୁଣୁ। ସୂତାକୁ ଆଗରୁ ବାନ୍ଧି ରଙ୍ଗ ଦିଆଯାଏ, ତା'ପରେ ତାନ୍ତରେ ବୁଣାଯାଏ। ଗୋଟିଏ ଶାଢ଼ୀ ପାଇଁ ଅନେକ ଦିନ ଲାଗେ।", en: "Hello, I am Kamala Meher. We weave Sambalpuri ikat. The thread is tied and dyed first, and only then woven on the loom. One saree takes many days." },
      { lang: "hi-IN", label: "Hindi", text: "नमस्ते, मैं कमला मेहर हूँ। हम संबलपुरी इकत बुनते हैं। पहले धागे को बांधकर रंगा जाता है, फिर करघे पर बुना जाता है। एक साड़ी बनाने में कई दिन लगते हैं।", en: "Hello, I am Kamala Meher. We weave Sambalpuri ikat. The thread is first tied and dyed, then woven on the loom. One saree takes many days." }
    ],
    studio: "loom",
    hotspots: [
      { x: 320, label: "Tie-and-dye yard", text: "Skeins are stretched on frames and tied with cotton thread wherever the dye should not reach." },
      { x: 860, label: "Pit loom", text: "Weavers match every tied thread to the design while weaving." },
      { x: 1400, label: "Finishing table", text: "Fringes are knotted by hand and the cloth is checked inch by inch." }
    ]
  },
  {
    id: "dibakar-sahoo",
    name: "Dibakar Sahoo",
    initials: "DS",
    craft: "Dhokra Brass Jewellery",
    village: "Sadeibereni",
    district: "Dhenkanal",
    state: "Odisha",
    lon: 85.6, lat: 20.66,
    coop: "Dhenkanal Dokra Jewellers Collective",
    generation: 4,
    since: 2001,
    members: 31,
    color: "#A6791C",
    gi: { name: "Dhokra (Odisha) lost-wax brass craft", status: "Sample record", id: "DEMO-GI-OD-0133", year: "—" },
    story: "The Dokra Damar community migrated across eastern India, carrying the lost-wax technique with them. Dibakar adapts its tribal motifs to wearable jewellery: delicate wax wire is coiled by hand into necklaces and jhumkas, then cast in brass so each piece looks like woven thread.",
    lineage: [
      ["Ancient", "Dokra Damar craftspeople trace the technique back thousands of years."],
      ["1970s", "The family settles in Dhenkanal and begins making ornaments for local festivals."],
      ["2001", "Dibakar begins designing wearable jewellery."],
      ["2018", "Forms a collective of 31 jewellers selling directly."]
    ],
    quote: "My wax thread is as thin as a hair. When it becomes brass, it still remembers my fingers.",
    audio: [
      { lang: "or-IN", label: "Odia", text: "ନମସ୍କାର, ମୁଁ ଦିବାକର ସାହୁ। ଆମେ ଢୋକରା ପିତ୍ତଳ ଗହଣା ତିଆରି କରୁ। ପ୍ରଥମେ ମହମର ସୂତା ଗୁଡ଼ାଇ ଛାଞ୍ଚ ତିଆରି ହୁଏ, ତା'ପରେ ତରଳ ପିତ୍ତଳ ଢଳାଯାଏ।", en: "Hello, I am Dibakar Sahoo. We make Dhokra brass jewellery. First wax thread is wound to make the form, then molten brass is poured in." },
      { lang: "bn-IN", label: "Bengali", text: "নমস্কার, আমি দিবাকর সাহু। আমরা ঢোকরা পদ্ধতিতে পিতলের গয়না তৈরি করি। প্রথমে মোমের সুতো জড়িয়ে কাঠামো বানাই, তারপর গলিত পিতল ঢালি।", en: "Hello, I am Dibakar Sahoo. We make brass jewellery by the Dhokra method. First we wind wax thread to make the form, then pour molten brass." }
    ],
    studio: "furnace",
    hotspots: [
      { x: 360, label: "Wax-thread bench", text: "Hair-thin wax threads are coiled into the jewellery shape." },
      { x: 900, label: "Casting pit", text: "Pre-heated moulds are filled with molten brass in a single pour." },
      { x: 1400, label: "Polishing wheel", text: "Pieces are cleaned with wire brushes and polished to a warm gold." }
    ]
  },
  {
    id: "meera-kumhar",
    name: "Meera Kumhar",
    initials: "MK",
    craft: "Jaipur Blue Pottery & Terracotta",
    village: "Amer Road, Jaipur",
    district: "Jaipur",
    state: "Rajasthan",
    lon: 75.82, lat: 26.92,
    coop: "Jaipur Neel Kumhar Mandal",
    generation: 3,
    since: 2008,
    members: 36,
    color: "#2457A6",
    gi: { name: "Jaipur Blue Pottery", status: "Registered GI (Rajasthan)", id: "DEMO-GI-RJ-0061", year: "2008" },
    story: "Jaipur's blue pottery uses no clay at all: a dough of quartz stone powder, powdered glass and gum is moulded, painted with cobalt oxide and fired at a low temperature. Meera, whose family are traditional kumhars (potters), also shapes hand-moulded terracotta from the same workshop.",
    lineage: [
      ["Persian roots", "The craft reaches India through Mughal-era Persian and Turkish influences."],
      ["1960s", "Revival led by master potters keeps the craft alive in Jaipur."],
      ["2008", "Meera starts her own studio, training women painters."],
      ["2020", "Studio turns to direct online sales."]
    ],
    quote: "Cobalt looks black until the fire. Then it turns to the blue of the sky.",
    audio: [
      { lang: "hi-IN", label: "Hindi", text: "नमस्ते, मैं मीरा कुम्हार हूँ, जयपुर से। हमारी ब्लू पॉटरी में मिट्टी नहीं, क्वार्ट्ज पत्थर का चूरा और कांच का पाउडर इस्तेमाल होता है। उस पर कोबाल्ट से हाथ से चित्र बनाते हैं और धीमी आंच में पकाते हैं।", en: "Hello, I am Meera Kumhar from Jaipur. Our blue pottery has no clay; we use quartz powder and ground glass. We paint by hand with cobalt and fire it slowly." }
    ],
    studio: "wheel",
    hotspots: [
      { x: 340, label: "Dough table", text: "Quartz powder, glass and gum are kneaded into a smooth dough." },
      { x: 880, label: "Painting corner", text: "Cobalt oxide is painted freehand with squirrel-hair brushes." },
      { x: 1400, label: "Kiln", text: "A low-temperature kiln fires the glazed pieces." }
    ]
  }
];

/* Step templates shared by crafts. pct = share of total craft hours. */
KK.techniques = {
  dhokra: [
    { t: "Clay core", d: "The figure's core is shaped from river clay mixed with rice husk, then dried in the shade.", days: 2, pct: 20, icon: "mound" },
    { t: "Wax threads", d: "Beeswax and sal resin are rolled into thin threads and coiled over the core to carve every detail.", days: 3, pct: 35, icon: "coil" },
    { t: "Clay mould", d: "Layers of clay cover the wax. A channel is left so the wax can drain and the metal can enter.", days: 3, pct: 15, icon: "shield" },
    { t: "Lost-wax casting", d: "The mould is fired, the wax melts out, and molten brass is poured into the empty space.", days: 1, pct: 15, icon: "flame" },
    { t: "Break & polish", d: "The mould is cracked open and the brass piece is chiselled and polished by hand.", days: 1, pct: 15, icon: "sparkle" }
  ],
  channapatna: [
    { t: "Season the wood", d: "Local wood is cut into blanks and seasoned for months to prevent cracking.", days: 3, pct: 10, icon: "mound" },
    { t: "Turn on the lathe", d: "The blank spins on the lathe while a hand-held chisel carves the shape.", days: 1, pct: 35, icon: "coil" },
    { t: "Lac coating", d: "Coloured lac sticks melt by friction against the spinning wood and set into a smooth coat.", days: 1, pct: 25, icon: "flame" },
    { t: "Colour layers", d: "Additional colours are layered and etched to create bands and patterns.", days: 1, pct: 20, icon: "brush" },
    { t: "Polish", d: "The piece is polished with leaf or cloth until the lacquer shines.", days: 1, pct: 10, icon: "sparkle" }
  ],
  bidri: [
    { t: "Cast the alloy", d: "A zinc-copper alloy is poured into a sand mould and cooled.", days: 2, pct: 15, icon: "flame" },
    { t: "Engrave", d: "The design is scratched into the surface by hand with fine steel chisels.", days: 4, pct: 30, icon: "coil" },
    { t: "Inlay silver", d: "Silver wire and sheet are hammered into the engraved grooves.", days: 4, pct: 30, icon: "shield" },
    { t: "Blacken", d: "A paste with Bidar Fort soil is rubbed on, turning the alloy black while the silver stays bright.", days: 1, pct: 10, icon: "mound" },
    { t: "Polish & oil", d: "The piece is buffed and rubbed with oil for a deep finish.", days: 1, pct: 15, icon: "sparkle" }
  ],
  ikat: [
    { t: "Design & skein", d: "The design is charted and yarn is wound into skeins to match it.", days: 3, pct: 10, icon: "mound" },
    { t: "Tie-resist", d: "Sections of the yarn are tied tightly so that dye will not reach them.", days: 6, pct: 25, icon: "coil" },
    { t: "Dye", d: "Yarn is dipped in colour baths; the tied sections stay undyed and the process is repeated for each colour.", days: 4, pct: 15, icon: "brush" },
    { t: "Set the loom", d: "The dyed warp is stretched and aligned thread by thread on the loom.", days: 3, pct: 15, icon: "shield" },
    { t: "Weave & finish", d: "Weft threads are woven across and fringes are knotted by hand.", days: 8, pct: 35, icon: "sparkle" }
  ],
  bluepottery: [
    { t: "Prepare the dough", d: "Quartz powder, powdered glass and gum are kneaded into a smooth dough.", days: 2, pct: 15, icon: "mound" },
    { t: "Mould & shape", d: "The dough is pressed into plaster moulds, then dried and smoothed.", days: 2, pct: 25, icon: "coil" },
    { t: "Paint", d: "Cobalt oxide designs are painted by hand freehand.", days: 2, pct: 30, icon: "brush" },
    { t: "Glaze", d: "A transparent glaze is applied to seal the piece.", days: 1, pct: 10, icon: "shield" },
    { t: "Fire", d: "The piece is fired at low temperature and cooled slowly.", days: 2, pct: 20, icon: "flame" }
  ],
  terracotta: [
    { t: "Dig & knead clay", d: "Local clay is dug, soaked and kneaded to remove air.", days: 1, pct: 15, icon: "mound" },
    { t: "Hand-mould", d: "The form is shaped by hand with coils and slabs.", days: 1, pct: 30, icon: "coil" },
    { t: "Dry & carve", d: "The piece dries slowly and then details are incised.", days: 3, pct: 25, icon: "brush" },
    { t: "Slip & burnish", d: "A fine slip is applied and burnished with a smooth stone.", days: 1, pct: 15, icon: "shield" },
    { t: "Kiln firing", d: "Pieces are fired in a wood kiln and cooled overnight.", days: 2, pct: 15, icon: "flame" }
  ]
};

/* Options used by the inquiry form, per craft technique. */
KK.finishes = {
  dhokra: ["Natural brass", "Antique dark", "Bright polish"],
  channapatna: ["Red & indigo", "Natural earth tones", "Pastel set"],
  bidri: ["Classic black + silver", "Matte black", "Brass-gold inlay"],
  ikat: ["Maroon & ivory", "Indigo & white", "Mustard & black"],
  bluepottery: ["Cobalt on white", "Cobalt & turquoise", "Turquoise on white"],
  terracotta: ["Natural terracotta", "Burnished dark", "Painted accent"]
};

/* Each product: costs in Rs. total = raw + labor(hours*rate) + profit + logistics + fee */
KK.products = [
  // --- Somu Baghel — Dhokra figures ---
  { id: "dhokra-tribal-figurine", name: "Dhokra Brass Tribal Figurine", artisan: "somu-baghel", craft: "dhokra", cat: "Brass Metalwork", mat: "Brass", hours: 16, rate: 75, raw: 400, profit: 600, logi: 0, fee: 200, art: "figurine", c: ["#C9A13B", "#8A5A1B"], size: "22 cm tall", desc: "A standing tribal figure with a coiled-thread headdress, cast in one piece by the lost-wax method." },
  { id: "dhokra-dancing-couple", name: "Dhokra Dancing Couple (Pair)", artisan: "somu-baghel", craft: "dhokra", cat: "Brass Metalwork", mat: "Brass", hours: 28, rate: 75, raw: 500, profit: 1100, logi: 120, fee: 300, art: "couple", c: ["#D2A94A", "#7A4A14"], size: "18 cm each", desc: "A pair of dancing figures, cast separately and balanced to stand together." },
  { id: "dhokra-bull-cart", name: "Dhokra Bull Cart Showpiece", artisan: "somu-baghel", craft: "dhokra", cat: "Brass Metalwork", mat: "Brass", hours: 22, rate: 80, raw: 430, profit: 900, logi: 140, fee: 270, art: "cart", c: ["#C08F2C", "#6B3E12"], size: "25 cm long", desc: "A village bull cart with turning wheels, a classic Bastar folk subject." },

  // --- Rukmini Gowda — Channapatna ---
  { id: "channapatna-spinning-tops", name: "Channapatna Lacquer Spinning Tops (Set of 6)", artisan: "rukmini-gowda", craft: "channapatna", cat: "Woodcraft", mat: "Wood", hours: 6, rate: 70, raw: 80, profit: 220, logi: 50, fee: 60, art: "tops", c: ["#C94C32", "#2B3A67", "#E8B93E"], size: "6 cm each", desc: "Six lac-turned tops in plant-based colours, safe for children." },
  { id: "channapatna-stacking-rings", name: "Channapatna Stacking Rings Toy", artisan: "rukmini-gowda", craft: "channapatna", cat: "Woodcraft", mat: "Wood", hours: 5, rate: 70, raw: 60, profit: 180, logi: 45, fee: 50, art: "rings", c: ["#D8553A", "#2E7D6B", "#E8B93E"], size: "15 cm tall", desc: "A set of seven wooden rings in lacquered colours that stack onto a turned spindle." },
  { id: "channapatna-jewellery-box", name: "Lacquered Wooden Jewellery Box", artisan: "rukmini-gowda", craft: "channapatna", cat: "Woodcraft", mat: "Wood", hours: 14, rate: 70, raw: 160, profit: 520, logi: 90, fee: 130, art: "box", c: ["#B5462B", "#E8B93E", "#2B3A67"], size: "12 × 12 × 8 cm", desc: "A round turned box with banded lacquer and a snug lid." },

  // --- Basavaraj Kamble — Bidri ---
  { id: "bidri-silver-vase", name: "Bidri Silver-Inlay Flower Vase", artisan: "basavaraj-kamble", craft: "bidri", cat: "Brass Metalwork", mat: "Brass", matNote: "Zinc–copper alloy, silver inlay", hours: 40, rate: 90, raw: 900, profit: 2000, logi: 250, fee: 600, art: "bidrivase", c: ["#1E2328", "#D7DBDF"], size: "24 cm tall", desc: "A hand-engraved vase with a classic floral lattice in pure silver on a black alloy." },
  { id: "bidri-trinket-box", name: "Bidri Inlay Trinket Box", artisan: "basavaraj-kamble", craft: "bidri", cat: "Brass Metalwork", mat: "Brass", matNote: "Zinc–copper alloy, silver inlay", hours: 18, rate: 90, raw: 380, profit: 880, logi: 120, fee: 260, art: "bidribox", c: ["#1E2328", "#D7DBDF"], size: "10 × 7 × 5 cm", desc: "A hinged box with a star-and-vine inlay, sized for rings and earrings." },
  { id: "bidri-pendant-set", name: "Bidri Silver-Inlay Pendant Set", artisan: "basavaraj-kamble", craft: "bidri", cat: "Jewellery", mat: "Brass", matNote: "Zinc–copper alloy, silver inlay", hours: 12, rate: 90, raw: 280, profit: 650, logi: 80, fee: 170, art: "pendant", c: ["#1E2328", "#D7DBDF"], size: "Pendant 4 cm", desc: "A matching pendant and earring set with fine silver floral inlay." },

  // --- Kamala Meher — Ikat ---
  { id: "sambalpuri-ikat-saree", name: "Sambalpuri Ikat Silk Saree", artisan: "kamala-meher", craft: "ikat", cat: "Handloom", mat: "Silk", hours: 120, rate: 80, raw: 3000, profit: 4800, logi: 300, fee: 1100, art: "saree", c: ["#7A2E4B", "#F1E3C4", "#C9A13B"], size: "5.5 m + blouse piece", desc: "A pure silk saree with chakra and shankha motifs tied and dyed before weaving." },
  { id: "sambalpuri-ikat-dupatta", name: "Sambalpuri Ikat Silk Dupatta", artisan: "kamala-meher", craft: "ikat", cat: "Handloom", mat: "Silk", hours: 36, rate: 80, raw: 900, profit: 1450, logi: 150, fee: 330, art: "dupatta", c: ["#2B3A67", "#F1E3C4", "#C94C32"], size: "2.3 m", desc: "A long dupatta with a woven border and ikat butis across the field." },
  { id: "sambalpuri-ikat-stole", name: "Sambalpuri Ikat Silk Stole", artisan: "kamala-meher", craft: "ikat", cat: "Handloom", mat: "Silk", hours: 18, rate: 80, raw: 420, profit: 760, logi: 100, fee: 180, art: "stole", c: ["#C9A13B", "#2A1F1A", "#F1E3C4"], size: "2 m × 70 cm", desc: "A light stole in hand-tied ikat, perfect for gifting." },

  // --- Dibakar Sahoo — Dhokra jewellery ---
  { id: "dhokra-tribal-necklace", name: "Dhokra Tribal Necklace", artisan: "dibakar-sahoo", craft: "dhokra", cat: "Jewellery", mat: "Brass", hours: 14, rate: 75, raw: 220, profit: 560, logi: 80, fee: 150, art: "necklace", c: ["#C9A13B", "#8A5A1B"], size: "Adjustable cord", desc: "A statement collar of wax-thread brass links in a tribal chain pattern." },
  { id: "dhokra-jhumka", name: "Dhokra Jhumka Earrings", artisan: "dibakar-sahoo", craft: "dhokra", cat: "Jewellery", mat: "Brass", hours: 6, rate: 75, raw: 70, profit: 240, logi: 40, fee: 70, art: "jhumka", c: ["#D2A94A", "#7A4A14"], size: "5 cm drop", desc: "Bell-shaped jhumkas in coiled wax-thread brass." },
  { id: "dhokra-lakshmi-lamp", name: "Dhokra Lakshmi Diya Lamp", artisan: "dibakar-sahoo", craft: "dhokra", cat: "Brass Metalwork", mat: "Brass", hours: 20, rate: 75, raw: 380, profit: 850, logi: 130, fee: 250, art: "lamp", c: ["#C08F2C", "#6B3E12"], size: "18 cm tall", desc: "A diya with a standing Lakshmi figure, cast in a single pour." },

  // --- Meera Kumhar — Blue pottery & terracotta ---
  { id: "blue-pottery-plate", name: "Jaipur Blue Pottery Floral Plate", artisan: "meera-kumhar", craft: "bluepottery", cat: "Pottery & Terracotta", mat: "Clay", matNote: "Quartz-glass dough (no clay)", hours: 9, rate: 70, raw: 90, profit: 330, logi: 80, fee: 100, art: "plate", c: ["#2457A6", "#FFFFFF", "#4AA3B5"], size: "25 cm diameter", desc: "A hand-painted plate with a cobalt floral border and glossy glaze." },
  { id: "blue-pottery-vase", name: "Jaipur Blue Pottery Vase", artisan: "meera-kumhar", craft: "bluepottery", cat: "Pottery & Terracotta", mat: "Clay", matNote: "Quartz-glass dough (no clay)", hours: 14, rate: 70, raw: 140, profit: 520, logi: 110, fee: 170, art: "bpvase", c: ["#2457A6", "#FFFFFF", "#4AA3B5"], size: "20 cm tall", desc: "A bulbous vase painted with vines and peacocks in cobalt blue." },
  { id: "terracotta-camel", name: "Rajasthani Terracotta Camel", artisan: "meera-kumhar", craft: "terracotta", cat: "Pottery & Terracotta", mat: "Clay", hours: 8, rate: 70, raw: 60, profit: 300, logi: 90, fee: 90, art: "camel", c: ["#B5532F", "#7A3419"], size: "20 cm tall", desc: "A hand-moulded camel with incised saddle patterns, fired in a wood kiln." }
];

/* Computed values for each product. */
KK.calc = function (p) {
  const labor = p.hours * p.rate;
  const total = p.raw + labor + p.profit + p.logi + p.fee;
  const direct = labor + p.profit;
  return {
    labor, total, direct,
    share: direct / total * 100,
    wageIndex: p.rate / KK.BENCHMARK_RATE,
    parts: [
      { key: "raw", label: "Raw materials", value: p.raw, color: "#7B5A3A", note: "Brass, wood, silk yarn, clay or silver bought by the artisan" },
      { key: "labor", label: "Craft labour", value: labor, color: "#B5462B", note: p.hours + " hours × ₹" + p.rate + "/hour" },
      { key: "profit", label: "Artisan net profit", value: p.profit, color: "#C9A13B", note: "Pays for tools, kiln/fuel, and the artisan's family" },
      { key: "logi", label: "Logistics", value: p.logi, color: "#4D6F8F", note: "Packing and insured shipping" },
      { key: "fee", label: "Platform fee", value: p.fee, color: "#2B3A67", note: "Runs KalaKart: hosting, verification, payments" }
    ]
  };
};

KK.byId = function (id) { return KK.products.find(p => p.id === id); };
KK.artisanById = function (id) { return KK.artisans.find(a => a.id === id); };
KK.inr = function (n) { return "₹" + Math.round(n).toLocaleString("en-IN"); };

/* Craft-region and price filter definitions. */
KK.brackets = [
  { id: "all", label: "Any price", min: 0, max: Infinity },
  { id: "b1", label: "Under ₹1,000", min: 0, max: 1000 },
  { id: "b2", label: "₹1,000 – ₹2,500", min: 1000, max: 2500 },
  { id: "b3", label: "₹2,500 – ₹6,000", min: 2500, max: 6000 },
  { id: "b4", label: "Above ₹6,000", min: 6000, max: Infinity }
];

/* ---------- Shared business logic (UI + server + tests) ---------- */
KK.SIZES = [
  { id: "s", label: "Small", f: 0.75, hint: "≈ 25% smaller" },
  { id: "m", label: "Standard", f: 1, hint: "As shown" },
  { id: "l", label: "Large", f: 1.5, hint: "≈ 50% larger" },
  { id: "c", label: "Custom size", f: 1.25, hint: "Artisan quotes" }
];
KK.TYPES = [
  { id: "custom", label: "Custom order", sub: "Change colour or finish" },
  { id: "bulk", label: "Bulk / gifting", sub: "10 or more pieces" },
  { id: "bespoke", label: "Bespoke dimensions", sub: "Your own size" },
  { id: "ask", label: "Just a question", sub: "No order yet" }
];
KK.LANGS = ["English", "Hindi", "Odia", "Bengali", "Kannada"];

/* Price + lead-time estimate for a size factor (f) and quantity (qty). */
KK.estimate = function (p, o) {
  const f = o.f, q = o.qty;
  const raw = p.raw * f * q, labor = p.hours * p.rate * f * q, profit = p.profit * f * q;
  const logi = p.logi * (1 + (f - 1) / 2) * (1 + (q - 1) * 0.7);
  const feeRate = p.fee / (p.raw + p.hours * p.rate + p.profit + p.logi);
  const fee = feeRate * (raw + labor + profit + logi);
  const total = raw + labor + profit + logi + fee;
  const direct = labor + profit;
  const base = KK.techniques[p.craft].reduce((s, x) => s + x.days, 0);
  const batches = Math.ceil(q / 5), lead = Math.ceil(base * batches * (f > 1 ? 1.2 : 1)) + 4;
  return { raw, labor, profit, logi, fee, total, direct, share: direct / total * 100, lead };
};

/* Validate + sanitise an inquiry. Used by the form and by server.js (never trust the client). */
KK.validateInquiry = function (b) {
  const errors = [], clean = {};
  const str = (v, max) => String(v == null ? "" : v).replace(/[\u0000-\u001f\u007f<>]/g, " ").replace(/\s+/g, " ").trim().slice(0, max);
  const p = KK.byId(str(b.product, 60));
  if (!p) errors.push("Choose a valid product.");
  clean.product = p ? p.id : "";
  clean.type = KK.TYPES.find(t => t.id === b.type) ? b.type : (errors.push("Choose a request type."), "");
  clean.size = KK.SIZES.find(s => s.id === b.size) ? b.size : (errors.push("Choose a size."), "");
  clean.finish = p && KK.finishes[p.craft].includes(b.finish) ? b.finish : (errors.push("Choose a finish."), "");
  const qty = Number(b.qty);
  if (!Number.isInteger(qty) || qty < 1 || qty > 500) errors.push("Quantity must be a whole number from 1 to 500.");
  clean.qty = qty;
  clean.dims = ["h", "w", "d"].map(k => { const v = b.dims && b.dims[k] !== "" && b.dims[k] != null ? Number(b.dims[k]) : null; if (v !== null && !(v >= 1 && v <= 300)) errors.push("Dimensions must be between 1 and 300 cm."); return v; });
  if (clean.size === "c" && clean.dims.every(v => v === null)) errors.push("Add at least one dimension for a custom size.");
  const dl = str(b.deadline, 10);
  if (dl) { const d = new Date(dl + "T00:00:00Z"); if (!/^\d{4}-\d{2}-\d{2}$/.test(dl) || isNaN(d)) errors.push("Deadline is not a valid date."); else if (d < new Date(new Date().toISOString().slice(0, 10) + "T00:00:00Z")) errors.push("Deadline cannot be in the past."); }
  clean.deadline = dl;
  clean.name = str(b.name, 80); if (!clean.name) errors.push("Name is required.");
  clean.email = str(b.email, 120); if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(clean.email)) errors.push("Enter a valid email address.");
  clean.phone = str(b.phone, 20); if (clean.phone && !/^[+()\-\s\d]{7,20}$/.test(clean.phone)) errors.push("Phone number looks invalid.");
  clean.city = str(b.city, 60);
  clean.lang = KK.LANGS.includes(b.lang) ? b.lang : "English";
  clean.msg = str(b.msg, 500);
  clean.note = !!b.note; clean.eco = !!b.eco;
  return { ok: errors.length === 0, errors, clean };
};

if (typeof module !== "undefined" && module.exports) module.exports = KK;
