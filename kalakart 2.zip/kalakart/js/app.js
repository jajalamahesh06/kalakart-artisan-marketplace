/* KalaKart — heritage handicraft marketplace (vanilla JS single-page app, hash routing) */
(function () {
  "use strict";

  const { inr, calc, byId, artisanById } = KK;
  const A = KKArt;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const app = $("#app");
  let uidN = 0;
  const uid = () => "u" + (++uidN);
  const pct = n => (Math.round(n * 10) / 10).toString().replace(/\.0$/, "") + "%";

  /* ---------- safe localStorage ---------- */
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* private mode */ } }
  };

  /* ---------- filter state ---------- */
  const filters = { state: "all", mat: "all", bracket: "all", q: "", sort: "featured" };
  const PAGE = 12;
  let shown = PAGE;

  /* ================= ROUTER ================= */
  function parseHash() {
    const h = location.hash.replace(/^#/, "") || "/";
    const [path, query] = h.split("?");
    const parts = path.split("/").filter(Boolean);
    const params = Object.fromEntries(new URLSearchParams(query || ""));
    return { parts, params };
  }

  function route() {
    stopAudio();
    stopPano();
    const { parts, params } = parseHash();
    const head = parts[0] || "";
    let scrollTo = null;
    try {
      if (head === "product" && byId(parts[1])) viewProduct(byId(parts[1]));
      else if (head === "artisan" && artisanById(parts[1])) viewArtisan(artisanById(parts[1]));
      else if (head === "inquiry") viewInquiry(params.product);
      else { viewHome(); if (["gallery", "makers", "fair"].includes(head)) scrollTo = head; }
    } catch (err) {
      console.error(err);
      app.innerHTML = `<section class="wrap" style="padding:64px 0"><h1>Something went wrong</h1><p class="lead">This page could not be displayed. Please go back to the home page.</p><a class="btn primary" href="#/">Back to home</a></section>`;
    }
    setActiveNav(head);
    $("#nav").classList.remove("open");
    $("#navToggle").setAttribute("aria-expanded", "false");
    if (scrollTo) { const el = document.getElementById(scrollTo); if (el) el.scrollIntoView({ behavior: "smooth", block: "start" }); }
    else window.scrollTo(0, 0);
    app.focus({ preventScroll: true });
  }

  function setActiveNav(head) {
    $$("#nav a").forEach(a => a.classList.toggle("active", a.dataset.route === (["product"].includes(head) ? "gallery" : head === "artisan" ? "makers" : head || "home")));
  }

  /* ================= SHARED COMPONENTS ================= */
  function earningsBadge(p) {
    const c = calc(p);
    return `<span class="badge-earn" title="Craft labour + artisan profit go straight to the maker"><b>${pct(c.share)}</b> to the maker · ${inr(c.direct)}</span>`;
  }

  function productCard(p) {
    const c = calc(p), a = artisanById(p.artisan);
    return `<article class="card">
      <a class="card-link" href="#/product/${p.id}" aria-label="${esc(p.name)}, ${inr(c.total)}">
        <div class="card-art">${A.product(p, uid())}<span class="card-cat">${esc(p.cat)}</span></div>
        <div class="card-body">
          <h3>${esc(p.name)}</h3>
          <p class="by">by ${esc(a.name)} · ${esc(a.village)}, ${esc(a.state)}</p>
          <div class="price-row"><span class="price">${inr(c.total)}</span>${earningsBadge(p)}</div>
          <div class="mini-bar" aria-hidden="true">${c.parts.map(x => `<i style="flex:${x.value};background:${x.color}"></i>`).join("")}</div>
        </div>
      </a></article>`;
  }

  /* Interactive stacked bar. parts = [{label,value,color,note}] */
  function stackedBar(parts, total, id, opts) {
    opts = opts || {};
    const vis = parts.filter(x => x.value > 0);
    return `<div class="stack" id="${id}" data-total="${total}">
      <div class="stack-bar" role="list" aria-label="Price components, in proportion">
        ${vis.map((x, i) => `<button type="button" role="listitem" class="seg" data-i="${parts.indexOf(x)}" style="--w:${x.value / total * 100}%;--c:${x.color}" aria-label="${esc(x.label)} ${inr(x.value)}, ${pct(x.value / total * 100)}">
          <span class="seg-label">${x.value / total > 0.07 ? pct(x.value / total * 100) : ""}</span></button>`).join("")}
      </div>
      <ul class="legend">
        ${parts.map((x, i) => `<li><button type="button" class="leg" data-i="${i}"><i style="background:${x.color}"></i><span class="leg-name">${esc(x.label)}</span><b>${inr(x.value)}</b></button></li>`).join("")}
      </ul>
      <div class="stack-detail" role="status" aria-live="polite" aria-atomic="true"><b>${esc(opts.hint || "Tap or hover any part of the bar")}</b></div>
    </div>`;
  }

  function bindStacked(root, parts, total, artisanKey) {
    const detail = $(".stack-detail", root);
    const set = i => {
      const x = parts[i];
      $$(".seg,.leg", root).forEach(el => el.classList.toggle("on", +el.dataset.i === i));
      detail.innerHTML = `<span class="dot" style="background:${x.color}"></span><b>${esc(x.label)} — ${inr(x.value)}</b> <span class="muted">(${pct(x.value / total * 100)} of price)</span><br><span class="muted">${esc(x.note || "")}</span>`;
    };
    $$(".seg,.leg", root).forEach(el => {
      ["mouseenter", "focus", "click"].forEach(ev => el.addEventListener(ev, () => set(+el.dataset.i)));
    });
    return set;
  }

  /* ================= HOME ================= */
  function viewHome() {
    document.title = "KalaKart — Buy heritage crafts directly from the artisan";
    const avg = KK.products.reduce((s, p) => s + calc(p).share, 0) / KK.products.length;
    const hero = byId("dhokra-tribal-figurine");
    app.innerHTML = `
    <section class="hero">
      <div class="wrap hero-grid">
        <div class="hero-copy">
          <p class="eyebrow">ArtisanFair · Direct from India's craft villages</p>
          <h1>Heritage crafts, <em>fairly priced</em>, straight from the maker's hands.</h1>
          <p class="lead">Traditional artisans often receive just 10–15% of what you pay in a boutique. On KalaKart every price is itemised and at least <b>75%</b> reaches the maker's own bank account.</p>
          <div class="cta-row">
            <a class="btn primary" href="#/gallery">Explore the gallery</a>
            <a class="btn ghost" href="#/product/${hero.id}">See a price breakdown</a>
          </div>
          <ul class="hero-stats">
            <li><b data-count="${KK.artisans.length}">0</b><span>master artisans</span></li>
            <li><b data-count="${KK.products.length}">0</b><span>authentic crafts</span></li>
            <li><b data-count="${Math.round(avg)}" data-suffix="%">0</b><span>average paid to makers</span></li>
          </ul>
        </div>
        <a class="hero-card" href="#/product/${hero.id}" aria-label="Open the Dhokra Brass Tribal Figurine">
          <div class="hero-art">${A.product(hero, uid())}</div>
          <div class="hero-card-foot"><div><b>${esc(hero.name)}</b><span>Somu Baghel · Bastar</span></div><div class="ring-mini">${pct(calc(hero).share)}<small>to maker</small></div></div>
        </a>
      </div>
    </section>

    <section class="section" id="fair">
      <div class="wrap">
        <header class="sec-head"><p class="eyebrow">Why it matters</p><h2>Where does your money go?</h2>
          <p>Compare the usual retail chain with a KalaKart purchase for the same handcrafted piece. Tap a bar to switch.</p></header>
        <div class="compare" id="compare">
          <div class="tabs" role="tablist" aria-label="Compare price flow">
            <button role="tab" aria-selected="false" data-mode="chain">Typical retail chain</button>
            <button role="tab" aria-selected="true" data-mode="kk">KalaKart direct</button>
          </div>
          <div class="compare-body"></div>
        </div>
      </div>
    </section>

    <section class="section alt" id="gallery">
      <div class="wrap">
        <header class="sec-head"><p class="eyebrow">Heritage Handicraft Gallery</p><h2>Handmade by master artisans</h2>
          <p>Jewellery, handlooms, terracotta and brass metalwork. Filter by craft region, material and price.</p></header>
        <div class="filters" id="filters">
          <div class="f-group"><span class="f-label" id="lbl-state">Craft region</span>
            <div class="chips" role="group" aria-labelledby="lbl-state">${chip("state", "all", "All regions")}${["Karnataka", "Odisha", "Rajasthan", "Chhattisgarh"].map(s => chip("state", s, s)).join("")}</div></div>
          <div class="f-group"><span class="f-label" id="lbl-mat">Material</span>
            <div class="chips" role="group" aria-labelledby="lbl-mat">${chip("mat", "all", "All")}${["Clay", "Brass", "Silk", "Wood"].map(s => chip("mat", s, s)).join("")}</div></div>
          <div class="f-row">
            <label class="f-field">Price<select id="fBracket">${KK.brackets.map(b => `<option value="${b.id}">${b.label}</option>`).join("")}</select></label>
            <label class="f-field">Sort<select id="fSort"><option value="featured">Featured</option><option value="lo">Price: low to high</option><option value="hi">Price: high to low</option><option value="share">Highest artisan share</option></select></label>
            <label class="f-field grow">Search<input id="fQ" type="search" placeholder="Dhokra, silk, vase…" autocomplete="off"></label>
          </div>
        </div>
        <p class="count" id="count" aria-live="polite"></p>
        <div class="grid" id="grid"></div>
      </div>
    </section>

    <section class="section" id="makers">
      <div class="wrap">
        <header class="sec-head"><p class="eyebrow">Meet the makers</p><h2>Six master artisans, six villages</h2>
          <p>Each maker has a story, a lineage and a Geographical Indication (GI) credential you can verify.</p></header>
        <div class="makers-grid">
          <div class="map-card"><h3>Village clusters</h3><div class="map" id="map">${A.indiaMap(KK.artisans)}</div><p class="muted small">Tap a pin to open the artisan's profile.</p></div>
          <div class="maker-list">${KK.artisans.map(makerCard).join("")}</div>
        </div>
      </div>
    </section>

    <section class="section alt how">
      <div class="wrap">
        <header class="sec-head"><p class="eyebrow">How it works</p><h2>Three steps, no middlemen</h2></header>
        <ol class="steps3">
          <li><span class="n">1</span><h3>Discover</h3><p>Read the maker's story and the full cost breakdown on every piece.</p></li>
          <li><span class="n">2</span><h3>Ask the artisan</h3><p>Use the structured form for custom sizes, finishes, bulk gifts and deadlines. It goes to the cooperative directly.</p></li>
          <li><span class="n">3</span><h3>Pay the maker</h3><p>The labour and profit share is paid to the maker's own bank account, and you see the exact rupee amount.</p></li>
        </ol>
      </div>
    </section>`;

    // counters
    $$("[data-count]").forEach(el => countUp(el, +el.dataset.count, el.dataset.suffix || ""));
    // filters
    $$("#filters .chip").forEach(b => b.addEventListener("click", () => { filters[b.dataset.k] = b.dataset.v; syncChips(); renderGrid(); }));
    $("#fBracket").value = filters.bracket; $("#fSort").value = filters.sort; $("#fQ").value = filters.q;
    $("#fBracket").addEventListener("change", e => { filters.bracket = e.target.value; renderGrid(); });
    $("#fSort").addEventListener("change", e => { filters.sort = e.target.value; renderGrid(); });
    $("#fQ").addEventListener("input", e => { filters.q = e.target.value; renderGrid(); });
    syncChips(); renderGrid();
    bindMap($("#map"));
    bindCompare();
  }

  function chip(k, v, label) { return `<button type="button" class="chip" data-k="${k}" data-v="${v}" aria-pressed="false">${label}</button>`; }
  function syncChips() { $$("#filters .chip").forEach(b => { const on = filters[b.dataset.k] === b.dataset.v; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); }); }

  function renderGrid(keep) {
    if (!keep) shown = PAGE;
    const br = KK.brackets.find(b => b.id === filters.bracket);
    const q = filters.q.trim().toLowerCase();
    let list = KK.products.filter(p => {
      const a = artisanById(p.artisan), t = calc(p).total;
      if (filters.state !== "all" && a.state !== filters.state) return false;
      if (filters.mat !== "all" && p.mat !== filters.mat) return false;
      if (t < br.min || t >= br.max) return false;
      if (q && !(p.name + " " + p.cat + " " + p.mat + " " + a.name + " " + a.state + " " + a.craft + " " + (p.matNote || "")).toLowerCase().includes(q)) return false;
      return true;
    });
    if (filters.sort === "lo") list.sort((x, y) => calc(x).total - calc(y).total);
    if (filters.sort === "hi") list.sort((x, y) => calc(y).total - calc(x).total);
    if (filters.sort === "share") list.sort((x, y) => calc(y).share - calc(x).share);
    const visible = list.slice(0, shown);
    $("#count").textContent = "Showing " + visible.length + " of " + list.length + " crafts (" + KK.products.length + " in total)";
    $("#grid").innerHTML = list.length ? visible.map(productCard).join("") + (list.length > shown ? `<div class="more"><button class="btn ghost" id="moreBtn">Show ${Math.min(PAGE, list.length - shown)} more</button></div>` : "") :
      `<div class="empty"><b>No crafts match these filters.</b><button class="btn ghost" id="resetF">Clear filters</button></div>`;
    const mb = $("#moreBtn"); if (mb) mb.onclick = () => { shown += PAGE; renderGrid(true); };
    const r = $("#resetF"); if (r) r.onclick = () => { Object.assign(filters, { state: "all", mat: "all", bracket: "all", q: "", sort: "featured" }); $("#fBracket").value = "all"; $("#fSort").value = "featured"; $("#fQ").value = ""; syncChips(); renderGrid(); };
  }

  function makerCard(a) {
    const n = KK.products.filter(p => p.artisan === a.id).length;
    return `<a class="maker" href="#/artisan/${a.id}">
      <span class="avatar" style="background:${a.color}">${a.initials}</span>
      <span class="maker-info"><b>${esc(a.name)}</b><span>${esc(a.craft)}</span><span class="muted">${esc(a.village)}, ${esc(a.state)} · ${n} crafts</span></span>
      <span class="gi-mini">GI</span></a>`;
  }

  function bindMap(root) {
    $$(".pin", root).forEach(g => {
      const go = () => { location.hash = "#/artisan/" + g.dataset.artisan; };
      g.addEventListener("click", go);
      g.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
    });
  }

  function bindCompare() {
    const root = $("#compare"), body = $(".compare-body", root);
    const demo = byId("dhokra-tribal-figurine"), c = calc(demo);
    const chain = [
      { label: "Artisan", value: 12, color: "#B5462B", note: "Artisans typically receive about 10–15% of the final retail price." },
      { label: "Middleman / trader", value: 23, color: "#8a8a8a", note: "Collects, stores and resells to boutiques at a small margin." },
      { label: "Boutique & retail markup", value: 65, color: "#4a4a4a", note: "Rent, branding and a markup of up to 500% over what the artisan is paid." }
    ];
    const show = mode => {
      $$("[role=tab]", root).forEach(t => t.setAttribute("aria-selected", t.dataset.mode === mode));
      if (mode === "chain") {
        const price = 4000;
        body.innerHTML = `<p class="cmp-head">A piece that sells for <b>${inr(price)}</b> in a city boutique <span class="muted">(illustrative)</span></p>
          ${stackedBar(chain.map(x => ({ ...x, value: x.value * price / 100 })), price, "cmpChain", { hint: "Tap a section to see who gets what" })}
          <p class="cmp-note bad">The maker's share: about <b>${inr(price * 0.12)}</b> for days of skilled work.</p>`;
        bindStacked($("#cmpChain"), chain.map(x => ({ ...x, value: x.value * price / 100 })), price);
      } else {
        const price = c.total;
        body.innerHTML = `<p class="cmp-head">${esc(demo.name)} sells for <b>${inr(price)}</b> on KalaKart</p>
          ${stackedBar(c.parts, price, "cmpKK")}
          <p class="cmp-note good">The maker's share (labour + profit): <b>${inr(c.direct)} — ${pct(c.share)}</b>.</p>`;
        bindStacked($("#cmpKK"), c.parts, price)(1);
      }
    };
    $$("[role=tab]", root).forEach(t => t.addEventListener("click", () => show(t.dataset.mode)));
    show("kk");
  }

  /* ================= PRODUCT PAGE ================= */
  function viewProduct(p) {
    const a = artisanById(p.artisan), c = calc(p);
    document.title = p.name + " — KalaKart";
    const steps = KK.techniques[p.craft];
    const days = steps.reduce((s, x) => s + x.days, 0);
    const related = KK.products.filter(x => x.id !== p.id && (x.artisan === p.artisan || x.cat === p.cat)).slice(0, 3);
    app.innerHTML = `
    <div class="wrap crumbs"><a href="#/gallery">Gallery</a> <span>/</span> <a href="#/artisan/${a.id}">${esc(a.name)}</a> <span>/</span> <span>${esc(p.name)}</span></div>

    <section class="wrap prod-top">
      <div class="prod-art">${A.product(p, uid())}</div>
      <div class="prod-info">
        <p class="eyebrow">${esc(p.cat)} · ${esc(p.mat)}${p.matNote ? " (" + esc(p.matNote) + ")" : ""}</p>
        <h1>${esc(p.name)}</h1>
        <p class="lead">${esc(p.desc)}</p>
        <dl class="facts">
          <div><dt>Size</dt><dd>${esc(p.size)}</dd></div>
          <div><dt>Crafting time</dt><dd>${p.hours} hours · ~${days} days</dd></div>
          <div><dt>Craft</dt><dd>${esc(a.craft)}</dd></div>
          <div><dt>GI</dt><dd>${esc(a.gi.name)}</dd></div>
        </dl>
        <div class="buy">
          <div class="big-price">${inr(c.total)}<small>incl. all itemised costs</small></div>
          <a class="btn primary" href="#/inquiry?product=${p.id}">${A.icon("send", 18)} Enquire or customise</a>
        </div>
        <div class="maker-strip"><a class="maker flat" href="#/artisan/${a.id}"><span class="avatar" style="background:${a.color}">${a.initials}</span><span class="maker-info"><b>${esc(a.name)}</b><span class="muted">${esc(a.village)}, ${esc(a.district)}, ${esc(a.state)}</span></span></a>${earningsBadge(p)}</div>
      </div>
    </section>

    <section class="section alt" id="price">
      <div class="wrap two">
        <div>
          <header class="sec-head left"><p class="eyebrow">Transparent fair-price breakdown</p><h2>Exactly where ${inr(c.total)} goes</h2>
            <p>Every rupee is itemised. Hover, focus or tap a segment for details.</p></header>
          <div id="prodStack">${stackedBar(c.parts, c.total, "pStack")}</div>
          <table class="cost-table"><caption class="sr">Cost components</caption>
            <thead><tr><th scope="col">Component</th><th scope="col">Amount</th><th scope="col">Share</th><th scope="col">Goes to</th></tr></thead>
            <tbody>${c.parts.map(x => `<tr><th scope="row"><i style="background:${x.color}"></i>${esc(x.label)}</th><td>${inr(x.value)}</td><td>${pct(x.value / c.total * 100)}</td><td>${{ raw: "Material suppliers", labor: "Artisan", profit: "Artisan", logi: "Packers & couriers", fee: "KalaKart" }[x.key]}</td></tr>`).join("")}
            <tr class="tot"><th scope="row">Total</th><td>${inr(c.total)}</td><td>100%</td><td></td></tr></tbody></table>
        </div>
        <div class="meter-card" id="meter">${earningsMeter(p)}</div>
      </div>
    </section>

    <section class="section" id="process">
      <div class="wrap">
        <header class="sec-head"><p class="eyebrow">Craft technique walkthrough</p><h2>${days} days, ${p.hours} hours of skilled work</h2>
          <p>The labour-intensive process behind this piece, step by step.</p></header>
        <div id="steps">${techniqueHTML(p)}</div>
      </div>
    </section>

    <section class="section alt" id="maker">
      <div class="wrap two">
        <div>
          <header class="sec-head left"><p class="eyebrow">Meet the maker</p><h2>${esc(a.name)}, ${esc(a.village)}</h2></header>
          <blockquote class="quote">“${esc(a.quote)}”</blockquote>
          <p>${esc(a.story)}</p>
          <p><a class="link" href="#/artisan/${a.id}">Read full artisan story →</a></p>
        </div>
        <div>${audioHTML(a)}</div>
      </div>
    </section>

    <section class="section" id="verify">
      <div class="wrap two">
        <div>
          <header class="sec-head left"><p class="eyebrow">Authenticity</p><h2>Verify the GI tag</h2>
            <p>Run a simulated ledger check of this maker's Geographical Indication credential.</p></header>
          ${verifyHTML(a)}
        </div>
        <div>
          <header class="sec-head left"><p class="eyebrow">Virtual artisan studio</p><h2>Step inside the workshop</h2></header>
          ${panoHTML(a)}
        </div>
      </div>
    </section>

    ${related.length ? `<section class="section alt"><div class="wrap"><header class="sec-head"><h2>More from the makers</h2></header><div class="grid">${related.map(productCard).join("")}</div></div></section>` : ""}
    `;

    bindStacked($("#pStack"), c.parts, c.total)(1);
    bindMeter(p);
    bindTechnique(p);
    bindAudio($("#audio"), a);
    bindVerify($("#verify"), a);
    bindPano($("#pano"), a);
  }

  /* ----- Earnings meter ----- */
  function earningsMeter(p, label) {
    const c = calc(p), a = artisanById(p.artisan);
    const R = 78, C = 2 * Math.PI * R;
    const minAng = KK.MIN_SHARE / 100 * 360 - 90;
    const mx = 100 + (R + 0) * Math.cos(minAng * Math.PI / 180), my = 100 + R * Math.sin(minAng * Math.PI / 180);
    return `<h3>Artisan Direct Earnings Meter</h3>
      <div class="ring" style="--C:${C};--p:${c.share / 100}">
        <svg viewBox="0 0 200 200" role="img" aria-label="${pct(c.share)} goes directly to the artisan">
          <circle cx="100" cy="100" r="${R}" class="ring-bg"/>
          <circle cx="100" cy="100" r="${R}" class="ring-fg" transform="rotate(-90 100 100)" stroke-dasharray="${C}" stroke-dashoffset="${C}"/>
          <circle cx="${mx}" cy="${my}" r="6" class="ring-min"/>
        </svg>
        <div class="ring-text"><b data-count="${c.share.toFixed(1)}" data-suffix="%" data-dec="1">0%</b><span>to the maker</span></div>
      </div>
      <p class="ring-cap"><b>${inr(c.direct)}</b> of ${inr(c.total)} is paid into <b>${esc(a.name.split(" ")[0])}'s bank account</b>.</p>
      <ul class="meter-list">
        <li><span>${A.icon("rupee", 16)} Labour</span><b>${inr(c.labor)}</b></li>
        <li><span>${A.icon("heart", 16)} Net profit</span><b>${inr(p.profit)}</b></li>
        <li class="sum"><span>Direct to maker</span><b>${inr(c.direct)}</b></li>
      </ul>
      <div class="pledge"><span class="dot-min"></span> Platform pledge: minimum <b>${KK.MIN_SHARE}%</b> to the maker${c.share >= KK.MIN_SHARE ? " ✓ met" : ""}</div>
      <div class="wage"><div><span class="muted small">Fair-Wage Index</span><b>${c.wageIndex.toFixed(2)}×</b></div>
        <p class="small muted">Paid ₹${p.rate}/hour vs. an illustrative skilled-craft benchmark of ₹${KK.BENCHMARK_RATE}/hour.</p></div>
      <div class="vs"><div class="vs-row"><span>Typical retail chain</span><div class="vs-bar"><i style="width:12%;background:#8a8a8a"></i></div><b>~12%</b></div>
        <div class="vs-row"><span>KalaKart</span><div class="vs-bar"><i style="width:${c.share}%;background:var(--terracotta)"></i></div><b>${pct(c.share)}</b></div></div>`;
  }
  function bindMeter() {
    const root = $("#meter"); if (!root) return;
    requestAnimationFrame(() => {
      const fg = $(".ring-fg", root), ring = $(".ring", root);
      if (fg) { const C = +ring.style.getPropertyValue("--C"), pp = +ring.style.getPropertyValue("--p"); setTimeout(() => { fg.style.strokeDashoffset = C * (1 - pp); }, 60); }
      $$("[data-count]", root).forEach(el => countUp(el, +el.dataset.count, el.dataset.suffix || "", +el.dataset.dec || 0));
    });
  }

  /* ----- Technique walkthrough ----- */
  function techniqueHTML(p) {
    const steps = KK.techniques[p.craft], total = steps.reduce((s, x) => s + x.days, 0);
    let acc = 0;
    return `<div class="tech">
      <ol class="tech-nav" role="tablist" aria-label="Crafting steps">
        ${steps.map((s, i) => { const d0 = acc + 1; acc += s.days; return `<li><button type="button" role="tab" data-i="${i}" aria-selected="${i === 0}"><span class="n">${i + 1}</span><span class="tn"><b>${esc(s.t)}</b><small>Day ${d0}${s.days > 1 ? "–" + acc : ""}</small></span></button></li>`; }).join("")}
      </ol>
      <div class="tech-panel" id="techPanel" aria-live="polite"></div>
    </div>
    <div class="timeline" aria-hidden="true">${steps.map((s, i) => `<i style="flex:${s.days}" data-i="${i}"></i>`).join("")}</div>
    <div class="tech-ctrl"><button class="btn ghost" id="techPrev">${A.icon("left", 16)} Previous</button><button class="btn ghost" id="techPlay">${A.icon("play", 16)} Play process</button><button class="btn ghost" id="techNext">Next ${A.icon("right", 16)}</button><span class="muted small">${total} days in total, including drying and curing.</span></div>`;
  }
  let techTimer = null;
  function bindTechnique(p) {
    const steps = KK.techniques[p.craft];
    let cur = 0;
    const panel = $("#techPanel");
    const show = i => {
      cur = (i + steps.length) % steps.length;
      const s = steps[cur], hrs = Math.round(p.hours * s.pct / 100 * 10) / 10;
      $$(".tech-nav button").forEach(b => b.setAttribute("aria-selected", +b.dataset.i === cur));
      $$(".timeline i").forEach(el => el.classList.toggle("on", +el.dataset.i <= cur));
      panel.innerHTML = `<div class="step-art s${cur}"><span class="disc">${A.icon(s.icon, 44)}</span><span class="step-n">Step ${cur + 1} of ${steps.length}</span></div>
        <div class="step-text"><h3>${esc(s.t)}</h3><p>${esc(s.d)}</p>
        <ul class="chips2"><li>${A.icon("clock", 14)} ${hrs} craft hours</li><li>${s.days} ${s.days > 1 ? "days" : "day"} incl. drying</li><li>${s.pct}% of the labour</li></ul>
        <p class="muted small">Photo and video slot: add real step images in <code>media/</code> and reference them from <code>js/data.js</code>.</p></div>`;
    };
    $$(".tech-nav button").forEach(b => b.addEventListener("click", () => { stopTech(); show(+b.dataset.i); }));
    $("#techPrev").addEventListener("click", () => { stopTech(); show(cur - 1); });
    $("#techNext").addEventListener("click", () => { stopTech(); show(cur + 1); });
    $("#techPlay").addEventListener("click", e => {
      if (techTimer) { stopTech(); return; }
      show(0);
      $("#techPlay").innerHTML = A.icon("pause", 16) + " Pause";
      techTimer = setInterval(() => { if (cur >= steps.length - 1) { stopTech(); } else show(cur + 1); }, 2200);
    });
    function stopTech() { clearInterval(techTimer); techTimer = null; const b = $("#techPlay"); if (b) b.innerHTML = A.icon("play", 16) + " Play process"; }
    show(0);
  }

  /* ----- Audio craft story ----- */
  let currentAudio = null, simTimer = null, speaking = false;
  function stopAudio() {
    try { if ("speechSynthesis" in window) speechSynthesis.cancel(); } catch (e) { }
    if (currentAudio) { currentAudio.pause(); currentAudio = null; }
    clearTimeout(simTimer); speaking = false;
    $$(".audio.playing").forEach(el => { el.classList.remove("playing"); const b = $(".play", el); if (b) { b.innerHTML = A.icon("play", 22); b.setAttribute("aria-label", "Play story"); } });
  }
  function audioHTML(a) {
    return `<div class="audio" id="audio">
      <div class="audio-head"><span class="avatar sm" style="background:${a.color}">${a.initials}</span><div><b>Craft story in ${a.audio.map(x => x.label).join(" / ")}</b><span class="muted small">Spoken by ${esc(a.name)} · short clip</span></div></div>
      ${a.audio.length > 1 ? `<div class="chips" role="tablist" aria-label="Language">${a.audio.map((x, i) => `<button class="chip ${i === 0 ? "on" : ""}" role="tab" data-i="${i}" aria-selected="${i === 0}">${x.label}</button>`).join("")}</div>` : ""}
      <div class="player"><button class="play" aria-label="Play story">${A.icon("play", 22)}</button><div class="wave" aria-hidden="true">${Array.from({ length: 28 }, (_, i) => `<i style="--d:${(i * 73) % 11 / 10 + .3}s;--h:${20 + (i * 37) % 70}%"></i>`).join("")}</div></div>
      <p class="transcript" lang="${a.audio[0].lang}"></p>
      <details><summary>English translation</summary><p class="en"></p></details>
      <p class="muted small note"></p>
    </div>`;
  }
  function bindAudio(root, a) {
    if (!root) return;
    let idx = 0;
    const T = $(".transcript", root), EN = $(".en", root), note = $(".note", root), btn = $(".play", root);
    const load = i => { idx = i; const c = a.audio[i]; T.textContent = c.text; T.lang = c.lang; EN.textContent = c.en; note.textContent = ""; };
    load(0);
    $$(".chip", root).forEach(ch => ch.addEventListener("click", () => { stopAudio(); $$(".chip", root).forEach(x => { x.classList.remove("on"); x.setAttribute("aria-selected", "false"); }); ch.classList.add("on"); ch.setAttribute("aria-selected", "true"); load(+ch.dataset.i); }));
    btn.addEventListener("click", () => {
      if (root.classList.contains("playing")) { stopAudio(); return; }
      stopAudio();
      const clip = a.audio[idx];
      const finish = () => stopAudio();
      root.classList.add("playing"); btn.innerHTML = A.icon("pause", 22); btn.setAttribute("aria-label", "Stop story");
      if (clip.src) {                                   // real recording
        currentAudio = new Audio(clip.src); currentAudio.onended = finish; currentAudio.onerror = () => { finish(); note.textContent = "Could not load the recording. Please read the transcript."; }; const pr = currentAudio.play(); if (pr && pr.catch) pr.catch(() => { finish(); note.textContent = "Could not play the recording. Please read the transcript."; }); return;
      }
      if ("speechSynthesis" in window && typeof SpeechSynthesisUtterance !== "undefined") {
        const voices = speechSynthesis.getVoices() || [];
        const v = voices.find(x => x.lang.toLowerCase().replace("_", "-").startsWith(clip.lang.slice(0, 2).toLowerCase()));
        if (v) {
          try {
            const u = new SpeechSynthesisUtterance(clip.text); u.lang = clip.lang; u.voice = v; u.rate = 0.9;
            u.onend = finish;
            u.onerror = () => { finish(); note.textContent = "Audio playback failed on this device. Please read the transcript instead."; };
            speaking = true; speechSynthesis.speak(u);
          } catch (e) { finish(); note.textContent = "Audio playback is not available here. Please read the transcript."; return; }
          note.textContent = "Voice preview is synthesised on your device. Real artisan recordings can be added with an audio file in data.js.";
          return;
        }
      }
      note.textContent = "No " + clip.label + " voice is installed on this device, so this is a silent preview. Read the transcript, or add a real recording (audio[].src in data.js).";
      simTimer = setTimeout(finish, 15000);
    });
  }

  /* ----- GI verification (simulated) ----- */
  function verifyHTML(a) {
    return `<div class="verify" id="verifyBox">
      <div class="gi-card"><span class="gi-seal">${A.icon("shieldCheck", 30)}</span><div><b>${esc(a.gi.name)}</b><span class="muted small">${esc(a.gi.status)}${a.gi.year !== "—" ? " · " + a.gi.year : ""}</span><code>${esc(a.gi.id)}</code></div></div>
      <button class="btn primary" id="verifyBtn">${A.icon("cube", 18)} Verify on the ledger</button>
      <ol class="vlog" aria-live="polite"></ol>
      <div class="vresult" hidden></div>
      <p class="muted small">Simulation only: a SHA-256 hash is computed in your browser and a mock block is generated. No real blockchain or GI registry is contacted.</p>
    </div>`;
  }
  async function sha256(s) {
    try { const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)); return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join(""); }
    catch (e) { let h = 2166136261; const out = []; for (let r = 0; r < 8; r++) { for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i) + r; h = Math.imul(h, 16777619); } out.push((h >>> 0).toString(16).padStart(8, "0")); } return out.join(""); }
  }
  function bindVerify(root, a) {
    const btn = $("#verifyBtn", root), log = $(".vlog", root), res = $(".vresult", root);
    btn.addEventListener("click", async () => {
      btn.disabled = true; log.innerHTML = ""; res.hidden = true;
      const hash = await sha256([a.gi.id, a.id, a.gi.name, a.village].join("|"));
      const block = 4100000 + parseInt(hash.slice(0, 5), 16) % 90000;
      const steps = ["Looking up GI entry “" + a.gi.name + "”…", "Fetching " + a.name + "'s credential from the cooperative ledger…", "Hashing credential (SHA-256)…", "Waiting for 3 block confirmations…"];
      for (let i = 0; i < steps.length; i++) {
        const li = document.createElement("li"); li.textContent = steps[i]; log.appendChild(li);
        await new Promise(r => setTimeout(r, 650));
        li.classList.add("ok"); li.textContent = "✓ " + steps[i];
      }
      res.hidden = false;
      res.innerHTML = `<b>${A.icon("check", 18)} Credential verified (simulated)</b>
        <dl><dt>Craft</dt><dd>${esc(a.gi.name)}</dd><dt>Maker</dt><dd>${esc(a.name)}, ${esc(a.village)}</dd><dt>Block</dt><dd>#${block.toLocaleString("en-IN")}</dd><dt>Credential hash</dt><dd><code>${hash.slice(0, 16)}…${hash.slice(-8)}</code></dd><dt>Checked</dt><dd>${new Date().toLocaleString("en-IN")}</dd></dl>`;
      btn.disabled = false; btn.innerHTML = A.icon("cube", 18) + " Verify again";
    });
  }

  /* ----- 360° studio tour ----- */
  let panoRAF = null;
  function stopPano() { cancelAnimationFrame(panoRAF); panoRAF = null; }
  function panoHTML(a) {
    const scene = `<div class="scene">${A.panorama(a.studio, a.color)}${a.hotspots.map((h, i) => `<button type="button" class="hot" data-i="${i}" style="left:${h.x / A.PW * 100}%" aria-label="${esc(h.label)}"><span></span></button>`).join("")}</div>`;
    return `<div class="pano-wrap">
      <div class="pano" id="pano" tabindex="0" aria-label="360 degree view of ${esc(a.name)}'s workshop. Drag or use arrow keys to look around."><div class="track">${scene}${scene}</div><span class="pano-hint">Drag to look around</span></div>
      <div class="pano-ctrl"><button class="btn ghost" data-dir="-1" aria-label="Look left">${A.icon("left", 16)}</button><button class="btn ghost" id="panoAuto">${A.icon("play", 16)} Auto-rotate</button><button class="btn ghost" data-dir="1" aria-label="Look right">${A.icon("right", 16)}</button></div>
      <div class="hot-info" id="hotInfo" aria-live="polite"><b>Tap a glowing hotspot</b><span class="muted small"> to learn what happens in each corner of ${esc(a.name.split(" ")[0])}'s workshop.</span></div>
    </div>`;
  }
  function bindPano(root, a) {
    if (!root) return;
    const track = $(".track", root), scene = $(".scene", root);
    let off = 0, dragging = false, sx = 0, so = 0, auto = false, moved = 0;
    const W = () => scene.offsetWidth || 1;
    const apply = () => { const w = W(); off = ((off % w) + w) % w; track.style.transform = `translateX(${-off}px)`; };
    const to = x => { off = x; apply(); };
    root.addEventListener("pointerdown", e => { dragging = true; moved = 0; sx = e.clientX; so = off; });
    root.addEventListener("pointermove", e => {
      if (!dragging) return;
      moved = Math.abs(e.clientX - sx);
      if (moved > 6) { if (!root.classList.contains("grab")) { try { root.setPointerCapture(e.pointerId); } catch (x) { } root.classList.add("grab"); $(".pano-hint", root).style.opacity = 0; } to(so - (e.clientX - sx)); }
    });
    const end = () => { dragging = false; root.classList.remove("grab"); };
    root.addEventListener("pointerup", end); root.addEventListener("pointercancel", end);
    root.addEventListener("keydown", e => { if (e.key === "ArrowLeft") { to(off - 80); e.preventDefault(); } if (e.key === "ArrowRight") { to(off + 80); e.preventDefault(); } });
    $$("[data-dir]", root.parentNode).forEach(b => b.addEventListener("click", () => to(off + (+b.dataset.dir) * W() * 0.12)));
    const loop = () => { if (auto && !dragging) { off += 0.5; apply(); } panoRAF = requestAnimationFrame(loop); };
    panoRAF = requestAnimationFrame(loop);
    $("#panoAuto").addEventListener("click", e => { auto = !auto; $("#panoAuto").innerHTML = (auto ? A.icon("pause", 16) + " Stop" : A.icon("play", 16) + " Auto-rotate"); });
    $$(".hot", root).forEach(h => h.addEventListener("click", e => {
      if (moved > 6) return;
      const hs = a.hotspots[+h.dataset.i];
      $$(".hot", root).forEach(x => x.classList.toggle("on", x.dataset.i === h.dataset.i));
      $("#hotInfo").innerHTML = `<b>${esc(hs.label)}</b> <span>${esc(hs.text)}</span>`;
      const w = W(), target = hs.x / A.PW * w - root.clientWidth / 2;
      auto = false; $("#panoAuto").innerHTML = A.icon("play", 16) + " Auto-rotate";
      const from = off; let t0 = null;
      const anim = t => { t0 = t0 || t; const k = Math.min(1, (t - t0) / 500), e2 = 1 - Math.pow(1 - k, 3); to(from + (target - from) * e2); if (k < 1) requestAnimationFrame(anim); };
      requestAnimationFrame(anim);
    }));
    window.addEventListener("resize", apply, { passive: true });
    to(0);
  }

  /* ================= ARTISAN PAGE ================= */
  function viewArtisan(a) {
    document.title = a.name + " — KalaKart";
    const prods = KK.products.filter(p => p.artisan === a.id);
    const avg = prods.reduce((s, p) => s + calc(p).share, 0) / prods.length;
    app.innerHTML = `
    <div class="wrap crumbs"><a href="#/makers">Makers</a> <span>/</span> <span>${esc(a.name)}</span></div>
    <section class="wrap a-hero" style="--ac:${a.color}">
      <span class="avatar xl" style="background:${a.color}">${a.initials}</span>
      <div><p class="eyebrow">${esc(a.craft)}</p><h1>${esc(a.name)}</h1>
        <p class="lead">${esc(a.village)}, ${esc(a.district)} district, ${esc(a.state)}</p>
        <ul class="facts-inline">
          <li><b>${a.generation}</b> generations of makers</li><li><b>${new Date().getFullYear() - a.since}</b> years at the craft</li><li><b>${a.members}</b> in the cooperative</li><li><b>${pct(avg)}</b> average paid to maker</li>
        </ul>
        <div class="cta-row"><a class="btn primary" href="#/inquiry?product=${prods[0].id}">${A.icon("send", 18)} Message the cooperative</a></div>
      </div>
    </section>

    <section class="section alt">
      <div class="wrap two">
        <div>
          <header class="sec-head left"><p class="eyebrow">Artisan story &amp; craft origin</p><h2>The story behind the craft</h2></header>
          <blockquote class="quote">“${esc(a.quote)}”</blockquote>
          <p>${esc(a.story)}</p>
          <h3>Lineage</h3>
          <ol class="lineage">${a.lineage.map(l => `<li><b>${esc(l[0])}</b><span>${esc(l[1])}</span></li>`).join("")}</ol>
        </div>
        <div>
          <div class="origin-card">
            <h3>${A.icon("map", 18)} Craft origin</h3>
            <div class="map small" id="map">${A.indiaMap(KK.artisans, a.id)}</div>
            <dl class="origin-dl"><dt>Village</dt><dd>${esc(a.village)}</dd><dt>District</dt><dd>${esc(a.district)}, ${esc(a.state)}</dd><dt>Cooperative</dt><dd>${esc(a.coop)}</dd><dt>GI tag</dt><dd>${esc(a.gi.name)} <span class="muted">(${esc(a.gi.status)})</span></dd></dl>
          </div>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="wrap two">
        <div><header class="sec-head left"><p class="eyebrow">Authenticity</p><h2>GI credential check</h2></header>${verifyHTML(a)}</div>
        <div><header class="sec-head left"><p class="eyebrow">Hear the maker</p><h2>Craft story in ${a.audio.map(x => x.label).join(" &amp; ")}</h2></header>${audioHTML(a)}</div>
      </div>
    </section>

    <section class="section alt">
      <div class="wrap"><header class="sec-head"><p class="eyebrow">Virtual artisan studio</p><h2>Look around ${esc(a.name.split(" ")[0])}'s workshop</h2></header>${panoHTML(a)}</div>
    </section>

    <section class="section">
      <div class="wrap"><header class="sec-head"><p class="eyebrow">Crafts by ${esc(a.name.split(" ")[0])}</p><h2>${prods.length} handmade pieces</h2></header>
        <div class="grid">${prods.map(productCard).join("")}</div></div>
    </section>`;
    bindMap($("#map")); bindVerify($("#verifyBox").parentNode, a); bindAudio($("#audio"), a); bindPano($("#pano"), a);
  }

  /* ================= INQUIRY FORM ================= */
  const SIZES = KK.SIZES, TYPES = KK.TYPES;
  const SWATCH = ["#C9A13B", "#2B3A67", "#B5462B", "#2E7D6B", "#7A2E4B", "#6b4a2e"];

  const estimate = KK.estimate;

  function viewInquiry(pid) {
    document.title = "Enquire or customise — KalaKart";
    const sel = byId(pid) ? pid : "dhokra-tribal-figurine";
    const today = new Date(); const iso = d => d.toISOString().slice(0, 10);
    app.innerHTML = `
    <section class="wrap inq-head"><p class="eyebrow">Direct artisan inquiry</p><h1>Ask the maker, not a middleman</h1>
      <p class="lead">Choose from the options below. Your request goes straight to the artisan cooperative, who replies within 48 hours with a confirmed quote.</p></section>
    <div class="wrap inq-grid">
      <form id="inqForm" class="inq" novalidate>
        <fieldset><legend><span class="n">1</span> Which craft?</legend>
          <label class="f-field">Product<select id="iProd" name="product">${KK.artisans.map(a => `<optgroup label="${esc(a.name)} — ${esc(a.craft)}">${KK.products.filter(p => p.artisan === a.id).map(p => `<option value="${p.id}" ${p.id === sel ? "selected" : ""}>${esc(p.name)} (${inr(calc(p).total)})</option>`).join("")}</optgroup>`).join("")}</select></label>
          <div id="iMaker" class="maker-strip"></div>
        </fieldset>

        <fieldset><legend><span class="n">2</span> What do you need?</legend>
          <div class="opt-grid" id="oType">${TYPES.map((t, i) => `<label class="opt"><input type="radio" name="type" value="${t.id}" ${i === 0 ? "checked" : ""}><span><b>${t.label}</b><small>${t.sub}</small></span></label>`).join("")}</div>
        </fieldset>

        <fieldset><legend><span class="n">3</span> Size</legend>
          <div class="opt-grid" id="oSize">${SIZES.map((s, i) => `<label class="opt"><input type="radio" name="size" value="${s.id}" ${i === 1 ? "checked" : ""}><span><b>${s.label}</b><small>${s.hint}</small></span></label>`).join("")}</div>
          <div class="dims" id="dims" hidden>
            <label class="f-field">Height (cm)<input type="number" name="h" min="1" max="300" inputmode="decimal"></label>
            <label class="f-field">Width (cm)<input type="number" name="w" min="1" max="300" inputmode="decimal"></label>
            <label class="f-field">Depth (cm)<input type="number" name="d" min="1" max="300" inputmode="decimal"></label>
          </div>
        </fieldset>

        <fieldset><legend><span class="n">4</span> Colour &amp; finish</legend><div class="opt-grid" id="oFinish"></div></fieldset>

        <fieldset><legend><span class="n">5</span> Quantity &amp; deadline</legend>
          <div class="row2">
            <div class="f-field"><span>Quantity</span><div class="stepper"><button type="button" id="qMinus" aria-label="Decrease quantity">−</button><input id="iQty" name="qty" type="number" min="1" max="500" value="1" inputmode="numeric" aria-label="Quantity"><button type="button" id="qPlus" aria-label="Increase quantity">+</button></div>
              <div class="chips" id="qQuick">${[1, 2, 10, 25, 50].map(n => `<button type="button" class="chip" data-q="${n}">${n}</button>`).join("")}</div></div>
            <label class="f-field">Needed by<input id="iDate" name="deadline" type="date" min="${iso(today)}"></label>
          </div>
          <p class="hint" id="leadHint"></p>
          <label class="check"><input type="checkbox" name="note"> Include a handwritten note from the artisan (free)</label>
          <label class="check"><input type="checkbox" name="eco" checked> Plastic-free, reusable gift packaging</label>
        </fieldset>

        <fieldset><legend><span class="n">6</span> About you</legend>
          <div class="row2">
            <label class="f-field">Name<input name="name" autocomplete="name" required></label>
            <label class="f-field">Email<input name="email" type="email" autocomplete="email" required></label>
          </div>
          <div class="row2">
            <label class="f-field">Phone / WhatsApp (optional)<input name="phone" type="tel" autocomplete="tel" inputmode="tel"></label>
            <label class="f-field">City<input name="city" autocomplete="address-level2"></label>
          </div>
          <label class="f-field">Language for the artisan call<select name="lang">${KK.LANGS.map(l => `<option>${l}</option>`).join("")}</select></label>
          <label class="f-field">Anything else? (optional)<textarea name="msg" rows="3" maxlength="500" placeholder="E.g. a name to engrave, an occasion, a colour you have in mind…"></textarea></label>
        </fieldset>
        <p class="form-err" id="inqErr" role="alert" hidden></p>
        <button class="btn primary big" type="submit">${A.icon("send", 18)} Send to the artisan</button>
      </form>

      <aside class="estimate" id="est" aria-live="polite"></aside>
    </div>
    <section class="wrap"><div id="inqDone"></div><div id="inqList"></div></section>`;

    const form = $("#inqForm");
    const val = n => { const el = form.elements[n]; return el ? el.value : ""; };
    const cur = () => byId(val("product"));
    const opts = () => ({ f: SIZES.find(s => s.id === val("size")).f, qty: Math.max(1, Math.min(500, parseInt(val("qty"), 10) || 1)) });

    function renderFinish() {
      const p = cur(), fin = KK.finishes[p.craft];
      $("#oFinish").innerHTML = fin.map((f, i) => `<label class="opt sw"><input type="radio" name="finish" value="${esc(f)}" ${i === 0 ? "checked" : ""}><span><i style="background:${SWATCH[(i + p.id.length) % SWATCH.length]}"></i><b>${esc(f)}</b></span></label>`).join("");
      const a = artisanById(p.artisan);
      $("#iMaker").innerHTML = `<a class="maker flat" href="#/artisan/${a.id}"><span class="avatar" style="background:${a.color}">${a.initials}</span><span class="maker-info"><b>${esc(a.coop)}</b><span class="muted">Led by ${esc(a.name)} · ${esc(a.village)}, ${esc(a.state)}</span></span></a>`;
    }
    function renderEst() {
      const p = cur(), o = opts(), e = estimate(p, o), parts = [
        { label: "Raw materials", value: e.raw, color: "#7B5A3A", note: "" }, { label: "Craft labour", value: e.labor, color: "#B5462B", note: "" },
        { label: "Artisan net profit", value: e.profit, color: "#C9A13B", note: "" }, { label: "Logistics", value: e.logi, color: "#4D6F8F", note: "" }, { label: "Platform fee", value: e.fee, color: "#2B3A67", note: "" }];
      const d = new Date(); d.setDate(d.getDate() + e.lead);
      $("#est").innerHTML = `<h3>Live price estimate</h3>
        <p class="est-total">${inr(e.total)}<small>${o.qty > 1 ? "for " + o.qty + " pieces" : "for 1 piece"} · indicative</small></p>
        <div class="stack-bar mini">${parts.filter(x => x.value > 0).map(x => `<i style="flex:${x.value};background:${x.color}" title="${esc(x.label)} ${inr(x.value)}"></i>`).join("")}</div>
        <ul class="est-list">${parts.map(x => `<li><i style="background:${x.color}"></i><span>${x.label}</span><b>${inr(x.value)}</b></li>`).join("")}</ul>
        <div class="est-direct"><b>${inr(e.direct)}</b> (${pct(e.share)}) goes directly to the maker.</div>
        <p class="small muted">Earliest delivery ≈ <b>${d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</b> (${e.lead} days incl. shipping).</p>
        ${val("size") === "c" || val("type") === "bespoke" ? `<p class="small note-box">Custom dimensions: the artisan will confirm the final quote.</p>` : ""}`;
      const dl = val("deadline");
      const hint = $("#leadHint");
      if (dl) {
        const diff = Math.ceil((new Date(dl) - new Date(iso(new Date()))) / 86400000);
        hint.textContent = diff < e.lead ? "That date is tight. This order needs about " + e.lead + " days; the artisan will confirm what is possible." : "That works. The artisan needs about " + e.lead + " days.";
        hint.className = "hint " + (diff < e.lead ? "warn" : "ok");
      } else { hint.textContent = "Handcrafted orders need about " + e.lead + " days including drying and shipping."; hint.className = "hint"; }
    }
    renderFinish(); renderEst();
    form.addEventListener("input", e => {
      if (e.target.name === "size") $("#dims").hidden = e.target.value !== "c";
      if (e.target.name === "type" && e.target.value === "bulk" && (parseInt(val("qty"), 10) || 1) < 10) form.elements.qty.value = 10;
      if (e.target.name === "type" && e.target.value === "bespoke") { form.elements.size.value = "c"; $("#dims").hidden = false; }
      renderEst();
    });
    $("#iProd").addEventListener("change", () => { renderFinish(); renderEst(); });
    $("#qMinus").onclick = () => { form.elements.qty.value = Math.max(1, (+val("qty") || 1) - 1); renderEst(); };
    $("#qPlus").onclick = () => { form.elements.qty.value = Math.min(500, (+val("qty") || 1) + 1); renderEst(); };
    $$("#qQuick .chip").forEach(b => b.onclick = () => { form.elements.qty.value = b.dataset.q; renderEst(); });

    form.addEventListener("submit", async ev => {
      ev.preventDefault();
      const err = $("#inqErr"); err.hidden = true;
      const p = cur(), a = artisanById(p.artisan), o = opts(), e = estimate(p, o);
      const payload = {
        product: p.id, type: val("type"), size: val("size"), finish: val("finish"), qty: val("qty"),
        dims: { h: val("h"), w: val("w"), d: val("d") }, deadline: val("deadline"),
        name: val("name"), email: val("email"), phone: val("phone"), city: val("city"), lang: val("lang"), msg: val("msg"),
        note: form.elements.note.checked, eco: form.elements.eco.checked
      };
      const v = KK.validateInquiry(payload);
      if (!v.ok) { err.textContent = v.errors.join(" "); err.hidden = false; err.scrollIntoView({ block: "center", behavior: "smooth" }); return; }
      const c = v.clean, submitBtn = $("button[type=submit]", form);
      submitBtn.disabled = true;
      let ref = "KK-" + Date.now().toString(36).slice(-5).toUpperCase(), saved = "device";
      if (/^https?:$/.test(location.protocol)) {            // optional Node server (npm start)
        try {
          const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 4000);
          const r = await fetch("/api/inquiries", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload), signal: ctl.signal });
          clearTimeout(t);
          if (r.ok) { const j = await r.json(); ref = j.ref || ref; saved = "server"; }
          else if (r.status === 400) { const j = await r.json().catch(() => ({})); err.textContent = (j.errors || ["The server rejected this inquiry."]).join(" "); err.hidden = false; submitBtn.disabled = false; return; }
        } catch (x) { /* server not running: keep the local copy */ }
      }
      submitBtn.disabled = false;
      const rec = {
        ref, at: new Date().toISOString(), product: p.id, productName: p.name, artisan: a.name, coop: a.coop,
        type: TYPES.find(t => t.id === c.type).label, size: SIZES.find(s => s.id === c.size).label,
        dims: c.dims.some(x => x !== null) ? c.dims.map(x => x === null ? "–" : x).join(" × ") + " cm" : "",
        finish: c.finish, qty: c.qty, deadline: c.deadline, estimate: Math.round(e.total), direct: Math.round(e.direct),
        name: c.name, email: c.email, phone: c.phone, city: c.city, lang: c.lang, msg: c.msg, note: c.note, eco: c.eco, saved
      };
      const list = store.get("kalakart.inquiries", []); list.unshift(rec); store.set("kalakart.inquiries", list.slice(0, 50));
      $("#inqDone").innerHTML = `<div class="done" role="status"><span class="done-ico">${A.icon("check", 28)}</span><div><h2>Sent to ${esc(a.coop)}</h2>
        <p>Reference <b>${esc(ref)}</b>. ${esc(a.name)}'s cooperative will reply to <b>${esc(c.email)}</b> within 48 hours with a confirmed quote and delivery date. Estimated total <b>${inr(rec.estimate)}</b>, of which <b>${inr(rec.direct)}</b> goes directly to the maker.</p>
        <p class="small">${saved === "server" ? "Stored on the KalaKart server." : "Saved on this device (start the optional server with <code>npm start</code> to store inquiries centrally)."}</p></div></div>`;
      renderList();
      $("#inqDone").scrollIntoView({ behavior: "smooth", block: "center" });
      form.reset(); form.elements.product.value = p.id; renderFinish(); $("#dims").hidden = true; renderEst();
    });

    function renderList() {
      const list = store.get("kalakart.inquiries", []);
      $("#inqList").innerHTML = list.length ? `<h2 class="list-h">Your inquiries <small>(saved on this device)</small></h2>
        <ul class="inq-list">${list.map(r => `<li><div><b>${esc(r.productName)}</b> × ${r.qty}<span class="muted small"> · ${esc(r.type)} · ${esc(r.size)}${r.dims ? " " + esc(r.dims) : ""} · ${esc(r.finish)}${r.deadline ? " · by " + esc(r.deadline) : ""}</span><br><span class="muted small">${esc(r.ref)} · to ${esc(r.coop)} · ${new Date(r.at).toLocaleDateString("en-IN")}</span></div><div class="inq-r"><b>${inr(r.estimate)}</b><span class="status">Sent</span><button class="x" data-ref="${r.ref}" aria-label="Delete inquiry ${esc(r.ref)}">×</button></div></li>`).join("")}</ul>` : "";
      $$("#inqList .x").forEach(b => b.onclick = () => { store.set("kalakart.inquiries", store.get("kalakart.inquiries", []).filter(x => x.ref !== b.dataset.ref)); renderList(); });
    }
    renderList();
  }

  /* ================= UTIL ================= */
  function countUp(el, to, suffix, dec) {
    dec = dec || 0;
    const t0 = performance.now(), dur = 900;
    if (window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches) { el.textContent = to.toFixed(dec) + suffix; return; }
    const step = t => { const k = Math.min(1, (t - t0) / dur), v = to * (1 - Math.pow(1 - k, 3)); el.textContent = v.toFixed(dec) + suffix; if (k < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  }

  /* ================= BOOT ================= */
  $("#navToggle").addEventListener("click", () => { const o = $("#nav").classList.toggle("open"); $("#navToggle").setAttribute("aria-expanded", o); });
  window.addEventListener("hashchange", route);
  $("#year").textContent = new Date().getFullYear();
  route();
})();
